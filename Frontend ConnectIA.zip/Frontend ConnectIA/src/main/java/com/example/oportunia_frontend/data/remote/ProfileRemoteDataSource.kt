// data/remote/ProfileRemoteDataSource.kt
package com.example.oportunia_frontend.data.remote

import com.example.oportunia_frontend.data.remote.api.ProfileService
import com.example.oportunia_frontend.data.remote.dto.ProfileDto
import retrofit2.Response
import javax.inject.Inject

class ProfileRemoteDataSource @Inject constructor(
    private val profileService: ProfileService
) {
    suspend fun getProfiles(): Result<List<ProfileDto>> = safeApiCall {
        profileService.getProfiles()
    }

    /**
     * Llama al endpoint de actualización. Envía el ProfileDto en el body, espera un ProfileDto
     * actualizado y lo envuelve en Result<T> mediante safeApiCall.
     */
    suspend fun updateProfile(dto: ProfileDto): Result<ProfileDto> = safeApiCall {
        profileService.updateProfile(dto.id, dto)
    }

    /**
     * Función auxiliar que envuelve cualquier llamada de Retrofit en Result<T>.
     * Si la respuesta es exitosa y tiene body != null → Result.success(body),
     * si no → Result.failure(Exception(...)).
     */
    private suspend fun <T> safeApiCall(apiCall: suspend () -> Response<T>): Result<T> = try {
        val response = apiCall()
        if (response.isSuccessful) {
            response.body()?.let {
                Result.success(it)
            } ?: Result.failure(Exception("Response body was null"))
        } else {
            val errorBody = response.errorBody()?.string()
            Result.failure(Exception("API error ${response.code()}: $errorBody"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }
}
