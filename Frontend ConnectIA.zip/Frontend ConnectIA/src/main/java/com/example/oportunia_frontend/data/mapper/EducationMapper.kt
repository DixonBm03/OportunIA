package com.example.oportunia_frontend.data.mapper

import com.example.oportunia_frontend.data.remote.dto.EducationDto
import com.example.oportunia_frontend.domain.model.Education
import javax.inject.Inject

class EducationMapper @Inject constructor(){
    fun mapToDomain(dto: EducationDto): Education = Education(
        institution = dto.institution,
        degree = dto.degree,
        startDate = dto.startDate.orEmpty(),
        endDate = dto.endDate.orEmpty()
    )

    fun mapToDto(model: Education): EducationDto = EducationDto(
        institution = model.institution,
        degree = model.degree,
        startDate = model.startDate,
        endDate = model.endDate
    )
}