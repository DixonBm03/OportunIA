// data/di/NetworkModule.kt
package com.example.oportunia_frontend.data.di

import com.example.oportunia_frontend.data.remote.api.JobService
import com.example.oportunia_frontend.data.remote.api.ProfileService
import com.example.oportunia_frontend.data.remote.dto.ProfileDto
import com.example.oportunia_frontend.data.remote.interceptor.ResponseInterceptor
import com.example.oportunia_frontend.data.remote.serializer.JobDeserializer
import com.example.oportunia_frontend.data.remote.serializer.ProfileDeserializer
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    private const val BASE_URL = "https://67ea1a0dbdcaa2b7f5bae61d.mockapi.io/api/v1/"
    private const val DATE_FORMAT = "yyyy-MM-dd"

    @Provides
    @Singleton
    fun provideGson(): Gson = GsonBuilder()
        .registerTypeAdapter(ProfileDto::class.java, ProfileDeserializer())
        .registerTypeAdapter(JobDeserializer::class.java, JobDeserializer())
        .setDateFormat(DATE_FORMAT)
        .create()

    @Provides
    @Singleton
    fun provideLoggingInterceptor(): HttpLoggingInterceptor =
        HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY }

    @Provides
    @Singleton
    fun provideOkHttpClient(
        loggingInterceptor: HttpLoggingInterceptor,
        responseInterceptor: ResponseInterceptor
    ): OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .addInterceptor(responseInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    @Provides
    @Singleton
    fun provideRetrofit(
        okHttpClient: OkHttpClient,
        gson: Gson
    ): Retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create(gson))
        .client(okHttpClient)
        .build()

    @Provides
    @Singleton
    fun provideProfileService(retrofit: Retrofit): ProfileService =
        retrofit.create(ProfileService::class.java)

    @Provides
    @Singleton
    fun provideJobService(retrofit: Retrofit): JobService =
        retrofit.create(JobService::class.java)
}
