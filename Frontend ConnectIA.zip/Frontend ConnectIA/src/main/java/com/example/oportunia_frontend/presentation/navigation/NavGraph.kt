package com.example.oportunia_frontend.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.oportunia_frontend.presentation.ui.screens.LoginScreen
import com.example.oportunia_frontend.presentation.ui.screens.RegisterScreen
import com.example.oportunia_frontend.presentation.ui.screens.company.CompanyJobDetailScreen
import com.example.oportunia_frontend.presentation.ui.screens.company.CompanyMainScreen
import com.example.oportunia_frontend.presentation.ui.screens.company.CompanyNotificationsScreen
import com.example.oportunia_frontend.presentation.ui.screens.students.MainScreen
import com.example.oportunia_frontend.presentation.ui.screens.students.JobDetailScreen
import com.example.oportunia_frontend.presentation.ui.screens.students.MyApplicationsScreen
import com.example.oportunia_frontend.presentation.ui.screens.students.NotificationsScreen
import com.example.oportunia_frontend.presentation.viewmodel.LoginViewModel
import com.example.oportunia_frontend.presentation.viewmodel.RegisterViewModel
import com.example.oportunia_frontend.presentation.viewmodel.ProfileViewModel
import com.example.oportunia_frontend.presentation.viewmodel.JobViewModel

@Composable
fun MyApp(
    loginViewModel   : LoginViewModel,
    registerViewModel: RegisterViewModel,
    profileViewModel : ProfileViewModel,
    jobViewModel     : JobViewModel
) {
    val navController = rememberNavController()
    NavHost(navController, startDestination = "login") {

        // — GENÉRICOS —
        composable("login")    { LoginScreen(navController, loginViewModel) }
        composable("register") { RegisterScreen(navController, registerViewModel) }

        // — FLUJO DE ESTUDIANTE —
        // 1) MainScreen con tu BottomBar (Home/Resume/Jobs/Interview/Profile)
        composable("main") {
            MainScreen(navController, profileViewModel, jobViewModel)
        }

        // 2) Detalle de trabajo (desde JobsScreen)
        composable(
            "job_detail/{id}",
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) { backStackEntry ->
            JobDetailScreen(
                id = backStackEntry.arguments!!.getLong("id"),
                navController = navController,
                jobViewModel = jobViewModel
            )
        }

        // 3) My Applications (desde HomeScreen)
        composable("my_applications") {
            MyApplicationsScreen(navController, jobViewModel)
        }
        // 4) **Notificaciones de estudiante (agregamos esta ruta)**
        composable("notifications_screen") {
            NotificationsScreen(navController)
        }


        // — NUEVO: FLUJO DE EMPRESA —
        // 1) Pantalla principal de empresa (CompanyMainScreen)
        composable("company_main") {
            CompanyMainScreen(navController)
        }
        // 2) Detalle de trabajo de empresa, si se necesita (ya tenías esta ruta):
        composable(
            "company_job_detail/{id}",
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) { back ->
            CompanyJobDetailScreen(
                id = back.arguments!!.getLong("id"),
                navController = navController
            )
        }
        composable("company_notifications_screen") {
            CompanyNotificationsScreen(navController)
        }
    }
}
