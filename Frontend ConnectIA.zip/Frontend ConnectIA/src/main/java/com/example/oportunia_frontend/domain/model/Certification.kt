package com.example.oportunia_frontend.domain.model

data class Certification(
    val name: String,
    val issuer: String,
    val date: String
)
