// File: presentation/viewmodel/CompanyProfileViewModel.kt
package com.example.oportunia_frontend.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.oportunia_frontend.domain.model.CompanyProfile
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel sencillo que expone un StateFlow<CompanyProfile?>.
 *
 * En lugar de inyectar un repositorio real, aquí simulamos ("mockeamos")
 * la carga del perfil de empresa con datos quemados. Más adelante, cuando
 * conectes con un backend real, bastará cambiar la lógica interna para
 * llamar a tu repositorio en lugar de asignar valores estáticos.
 */
class CompanyProfileViewModel : ViewModel() {

    // 1) Flujo que contiene el perfil actual de la empresa.
    //    Inicialmente nulo (mientras "carga").
    private val _companyProfile = MutableStateFlow<CompanyProfile?>(null)
    val companyProfile = _companyProfile.asStateFlow()

    init {
        // Podemos precargar un valor “fake” aquí o bien dejar que
        // la UI invoque fetchCompanyProfile(). En este ejemplo,
        // no cargamos nada en init, para que la UI controle el momento de la llamada.
    }

    /**
     * Simula una llamada a API/Backend que obtiene el perfil de la empresa.
     * Aquí podrías retrasar un poco para simular tiempo de red.
     */
    fun fetchCompanyProfile() {
        viewModelScope.launch {
            // Simulamos retraso de red (por ejemplo 500 ms) para que se vea el loader:
            delay(500)

            // Asignamos datos “quemados” (los mismos que antes tenías en tu Composable)
            val mockProfile = CompanyProfile(
                id = 1L,
                name = "Microsoft",
                founded = "Established in 1975 by Bill Gates and Paul Allen",
                globalPresence = "Headquarters in Redmond, Washington y más de 200,000 empleados en todo el mundo",
                innovativeProducts = "Windows, Office, Azure, GitHub, Xbox",
                rAndDInvestment = "Amplia inversión en I+D para impulsar la innovación continua",
                enterpriseSolutions = "Soluciones empresariales robustas, seguras y escalables",
                mission = "Empoderar a cada persona y cada organización en el planeta para lograr más"
            )
            _companyProfile.value = mockProfile
        }
    }

    /**
     * Cuando la UI toca “Guardar” tras la edición, invocamos este método
     * con el nuevo CompanyProfile. Por ahora, simplemente reescribimos el flujo.
     * En un futuro real, aquí harías la llamada al repositorio/servicio para actualizar
     * en backend. Luego, una vez exitosa la actualización, actualizarías el StateFlow.
     */
    fun updateCompanyProfile(updated: CompanyProfile) {
        viewModelScope.launch {
            // Simulamos un delay de “guardado”:
            delay(300)

            // Asignamos el perfil actualizado
            _companyProfile.value = updated

            // Más adelante, si tienes backend, aquí harías:
            //  myRepository.updateCompanyProfile(updated).onSuccess { … } .onFailure { … }
        }
    }
}
