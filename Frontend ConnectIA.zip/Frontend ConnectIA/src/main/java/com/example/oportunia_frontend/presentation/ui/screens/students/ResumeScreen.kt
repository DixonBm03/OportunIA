package com.example.oportunia_frontend.presentation.ui.screens.students

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.example.oportunia_frontend.domain.model.Job
import com.example.oportunia_frontend.presentation.viewmodel.JobViewModel

@Composable
fun ResumeScreen(
    navController: NavController,
    jobViewModel: JobViewModel
) {
    // Al iniciar el Composable, solicitamos la lista de trabajos
    LaunchedEffect(Unit) {
        jobViewModel.getAllJobs()
    }

    // Scroll interno de la pantalla
    val scrollState = rememberScrollState()

    // Observamos el estado de la lista de trabajos desde el ViewModel
    val resumeData by jobViewModel.jobList.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        // Fondo azul en la parte superior
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(Color(0xFF2196F3))
        )

        // Contenido principal:
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp)
                .padding(top = 120.dp)   // deja espacio al fondo azul
        ) {
            // Tarjeta para subir el CV
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    UploadResumeBox()

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { /* Aquí podrías disparar algún análisis del CV */ },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2196F3)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Analysis", color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Título de "Recommendations"
            Text(
                text = "Recommendations",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Si resumeData es null (aún cargando), mostramos un indicador
            if (resumeData == null) {
                Text("Loading resume data...", color = Color.Gray)
            } else {
                // Por cada Job en la lista, mostramos un ítem clicable
                resumeData!!.forEach { job ->
                    ResumeRecommendationItem(
                        job = job,
                        navController = navController
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

/**
 * Caja punteada para simular el área de "subir CV".
 */
@Composable
fun UploadResumeBox() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .drawBehind {
                val dashWidth = 10f
                val dashGap = 10f
                val stroke = Stroke(
                    width = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(dashWidth, dashGap), 0f)
                )
                drawRoundRect(
                    color = Color.Gray,
                    style = stroke,
                    cornerRadius = CornerRadius(8.dp.toPx())
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.KeyboardArrowUp,
                contentDescription = "Upload Icon",
                tint = Color.Gray,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "upload resume", color = Color.Gray)
        }
    }
}

/**
 * Cada ítem de recomendación que aparece bajo "Recommendations".
 * Cuando el usuario hace click, navegamos a "job_detail/{id}" (ID de tipo Long).
 * Eso coincide exactamente con tu NavHost:
 *     composable("job_detail/{id}" … ) { JobDetailScreen(id, …) }
 */
@Composable
fun ResumeRecommendationItem(
    job: Job,
    navController: NavController
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                // IMPORTANTE: aquí pasamos el ID del trabajo, no el nombre.
                navController.navigate("job_detail/${job.id}")
            },
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.LightGray),
                contentAlignment = Alignment.Center
            ) {
                Text("Logo", fontSize = 10.sp)
            }
            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = job.organization.name,
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.Gray
                )
                Text(
                    text = job.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = job.organization.location,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = job.salary,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Black
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "More",
                    tint = Color.White
                )
            }
        }
    }
}
