package com.example.oportunia_frontend.presentation.ui.screens.students

import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.oportunia_frontend.R // ajusta el paquete

data class NotificationItem(
    val iconType: IconType,
    val avatarRes: Int? = null,
    val text: String,
    val timeAgo: String
)

enum class IconType { STAR, AVATAR, HEART }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(navController: NavController) {
    var selectedTab by remember { mutableStateOf("All") }
    val tabs = listOf("All", "Jobs", "Recommendations")

    // mock de datos
    val allNotifications = listOf(
        NotificationItem(IconType.STAR, null, "You have new job recommendations.", "5m"),
        NotificationItem(IconType.AVATAR, R.drawable.ic_launcher_background, "Arnoldo wants to connect with you.", "10m"),
        NotificationItem(IconType.HEART, null, "You have appeared in over +10 searches this week.", "30m")
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Notifications", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF2196F3))
            )
        }
    ) { inner ->
        Column(modifier = Modifier
            .fillMaxSize()
            .padding(inner))
        {
            // Row de filtros
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                tabs.forEach { tab ->
                    FilterChip(
                        selected = (tab == selectedTab),
                        onClick = { selectedTab = tab },
                        label = { Text(tab) }
                    )
                }
            }

            Divider()

            // Lista de notificaciones (aquí puedes filtrar según selectedTab)
            val itemsToShow = when (selectedTab) {
                "Jobs"           -> allNotifications.filter { it.iconType == IconType.STAR }
                "Recommendations"-> allNotifications.filter { it.iconType == IconType.AVATAR }
                else             -> allNotifications
            }

            LazyColumn {
                items(itemsToShow) { notif ->
                    NotificationRow(notif)
                    Divider()
                }
            }
        }
    }
}

@Composable
fun NotificationRow(item: NotificationItem) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        when (item.iconType) {
            IconType.STAR -> {
                Icon(Icons.Default.Star, contentDescription = null, tint = Color.Black)
            }
            IconType.AVATAR -> {
                item.avatarRes?.let { res ->
                    Image(
                        painter = painterResource(res),
                        contentDescription = null,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                }
            }
            IconType.HEART -> {
                Icon(Icons.Default.Favorite, contentDescription = null, tint = Color.Black)
            }
        }

        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(text = item.text, style = MaterialTheme.typography.bodyMedium)
        }

        Text(text = item.timeAgo, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
    }
}
