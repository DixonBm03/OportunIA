// File: data/repository/CompanyProfileRepositoryImpl.kt
package com.example.oportunia_frontend.data.repository

import com.example.oportunia_frontend.domain.model.CompanyProfile
import com.example.oportunia_frontend.domain.repository.CompanyProfileRepository
import kotlinx.coroutines.delay

/**
 * Implementación “mockeada” de CompanyProfileRepository.
 * En tu prueba actual no tienes un endpoint real, así que devolvemos datos estáticos
 * tras un pequeño retardo simulado (delay).
 */
class CompanyProfileRepositoryImpl : CompanyProfileRepository {

    // Datos quemados de ejemplo:
    private var currentProfile = CompanyProfile(
        id = 1L,
        name = "Microsoft",
        founded = "Established in 1975 by Bill Gates and Paul Allen.",
        globalPresence = "Headquarters in Redmond, Washington; +200,000 employees worldwide.",
        innovativeProducts = "Flagship: Windows, Office, Azure, etc.",
        rAndDInvestment = "Sizable R&D budget every año para innovación.",
        enterpriseSolutions = "Ofrece soluciones empresariales robustas y seguras.",
        mission = "Empoderar cada persona y cada organización en el planeta para lograr más."
    )

    override suspend fun getCompanyProfile(): Result<CompanyProfile> {
        // Simulamos que tardamos 1 segundo en cargar
        delay(1_000)
        return Result.success(currentProfile)
    }

    override suspend fun updateCompanyProfile(profile: CompanyProfile): Result<CompanyProfile> {
        // Simulamos que tardamos 1 segundo en guardar
        delay(1_000)
        // En un backend real harías un PUT /company/{id}
        // Aquí simplemente reemplazamos el valor interno
        currentProfile = profile
        return Result.success(currentProfile)
    }
}
