// File: domain/model/CompanyProfile.kt
package com.example.oportunia_frontend.domain.model

data class CompanyProfile(
    val id: Long,
    val name: String,
    val founded: String,
    val globalPresence: String,
    val innovativeProducts: String,
    val rAndDInvestment: String,
    val enterpriseSolutions: String,
    val mission: String
)
