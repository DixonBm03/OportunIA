package com.example.oportunia_frontend.data.mapper

import com.example.oportunia_frontend.data.remote.dto.ResumeDto
import com.example.oportunia_frontend.domain.model.Resume
import javax.inject.Inject

class ResumeMapper @Inject constructor(){
    fun mapToDomain(dto: ResumeDto): Resume = Resume(
        title = dto.title,
        fileUrl = dto.fileUrl
    )

    fun mapToDto(model: Resume): ResumeDto = ResumeDto(
        title = model.title,
        fileUrl = model.fileUrl
    )
}