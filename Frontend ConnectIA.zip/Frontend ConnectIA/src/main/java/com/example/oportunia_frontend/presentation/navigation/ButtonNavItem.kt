package com.example.oportunia_frontend.presentation.navigation


import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Represents items in the bottom navigation bar of the app.
 *
 * Each item contains:
 * - A unique route for navigation
 * - Display title
 * - Material icon
 *
 * @property route Unique navigation route for the screen
 * @property title Display name in the navigation bar
 * @property icon Material icon to display
 */
sealed class BottomNavItem(val route: String, val title: String, val icon: ImageVector) {
    object Home : BottomNavItem("home_screen", "Home", Icons.Default.Home)
    object Resume : BottomNavItem("resume_screen", "Resume", Icons.Default.Add)
    object Jobs : BottomNavItem("jobs_screen", "Jobs", Icons.Default.List)
    object Interview : BottomNavItem("interview_screen", "Interview", Icons.Default.Face)
    object Profile : BottomNavItem("profile_screen", "Profile", Icons.Default.Person)
}
