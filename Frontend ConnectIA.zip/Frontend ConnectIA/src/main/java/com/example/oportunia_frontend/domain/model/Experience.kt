package com.example.oportunia_frontend.domain.model

data class Experience(
    val company: String,
    val position: String,
    val startDate: String,
    val endDate: String
)
