package com.example.oportunia_frontend.presentation.ui.screens.students

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.oportunia_frontend.presentation.viewmodel.JobViewModel

@Composable
fun InterviewScreen(navController: NavController, jobViewModel: JobViewModel = viewModel()) {
    val scrollState = rememberScrollState()
    val jobList by jobViewModel.jobList.collectAsState()

    val positions = jobList.map { it.name }
    val levels = jobList.firstOrNull()?.level ?: emptyList()

    var selectedPosition by remember { mutableStateOf("") }
    var selectedLevel by remember { mutableStateOf("") }

    var showPositionDialog by remember { mutableStateOf(false) }
    var showLevelDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        jobViewModel.getAllJobs()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        if (jobList.isEmpty()) {
            Text("Loading job positions...", color = Color.Gray)
            return
        }

        SelectorField(
            label = "Position to Simulate",
            value = selectedPosition,
            onClear = { selectedPosition = "" },
            onClick = { showPositionDialog = true }
        )

        if (showPositionDialog) {
            SelectorDialog(
                title = "Select Position",
                options = positions,
                onSelect = {
                    selectedPosition = it
                    showPositionDialog = false
                },
                onDismiss = { showPositionDialog = false }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        SelectorField(
            label = "Level",
            value = selectedLevel,
            onClear = { selectedLevel = "" },
            onClick = { showLevelDialog = true }
        )

        if (showLevelDialog) {
            SelectorDialog(
                title = "Select Level",
                options = levels,
                onSelect = {
                    selectedLevel = it
                    showLevelDialog = false
                },
                onDismiss = { showLevelDialog = false }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                // lógica de inicio de entrevista
                println("Starting interview for $selectedPosition at level $selectedLevel")
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2196F3)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Start", color = Color.White)
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                modifier = Modifier.padding(start = 8.dp)
            )
        }
    }
}


@Composable
private fun SelectorField(
    label: String,
    value: String,
    onClear: () -> Unit,
    onClick: () -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = { },
        readOnly = true,
        label = { Text(label) },
        trailingIcon = {
            Row {
                if (value.isNotEmpty()) {
                    IconButton(onClick = onClear) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Clear")
                    }
                }
                IconButton(onClick = onClick) {
                    Icon(imageVector = Icons.Default.KeyboardArrowDown, contentDescription = "Select")
                }
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    )
}

@Composable
private fun SelectorDialog(
    title: String,
    options: List<String>,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        title = { Text(title) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                options.forEach { option ->
                    ListItem(
                        modifier = Modifier
                            .clickable { onSelect(option) }
                            .padding(vertical = 4.dp),
                        headlineContent = { Text(option) }
                    )
                }
            }
        }
    )
}