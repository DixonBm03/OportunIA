package com.example.oportunia_frontend.data.remote.dto

data class ExperienceDto(
    val company: String,
    val position: String,
    val startDate: String,
    val endDate: String
)
