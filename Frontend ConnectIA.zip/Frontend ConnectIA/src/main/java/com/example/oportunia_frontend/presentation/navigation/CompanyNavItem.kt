package com.example.oportunia_frontend.presentation.navigation


import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

/**
 * Items de la barra inferior sólo para el flujo de empresa.
 */
sealed class CompanyNavItem(val route: String, val title: String, val icon: ImageVector) {
    object Home          : CompanyNavItem("company_home",          "Home",      Icons.Default.Home)
    object Jobs          : CompanyNavItem("company_jobs",          "Jobs",      Icons.Default.List)
    object Notifications : CompanyNavItem("company_notifications", "Notifs",    Icons.Default.Notifications)
    object Candidates    : CompanyNavItem("company_cands",         "Cand list", Icons.Default.Face)
    object Profile       : CompanyNavItem("company_profile",       "Profile",   Icons.Default.Person)
}
