package com.example.oportunia_frontend.domain.model

data class Skill (
    val name: String,
    val level: String
)