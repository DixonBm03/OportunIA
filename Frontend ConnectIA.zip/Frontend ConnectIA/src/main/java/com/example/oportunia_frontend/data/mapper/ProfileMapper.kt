package com.example.oportunia_frontend.data.mapper

import com.example.oportunia_frontend.data.remote.dto.ProfileDto
import com.example.oportunia_frontend.domain.model.Profile
import javax.inject.Inject

/**
 * Mapper class for converting between [ProfileDto] and [Profile] domain models.
 */
class ProfileMapper @Inject constructor (
    private val skillMapper: SkillMapper,
    private val educationMapper: EducationMapper,
    private val experienceMapper: ExperienceMapper,
    private val certificationMapper: CertificationMapper,
    private val resumeMapper: ResumeMapper
) {
    /**
     * Maps a [ProfileDto] to a [Profile] domain model.
     *
     * @param dto The [ProfileDto] to be mapped.
     * @return The mapped [Profile] domain model.
     */
    fun mapToDomain(dto: ProfileDto): Profile = Profile(
        id = dto.id,
        firstName = dto.firstName,
        lastName = dto.lastName,
        email = dto.email,
        contactNumber = dto.contactNumber,
        headline = dto.headline,
        bio = dto.bio,
        location = dto.location,
        dob = dto.dob,
        gender = dto.gender,
        skills = dto.skills.map { skillMapper.mapToDomain(it) },
        educations = dto.educations.map { educationMapper.mapToDomain(it)},
        experiences = dto.experiences.map { experienceMapper.mapToDomain(it) },
        certifications = dto.certifications.map { certificationMapper.mapToDomain(it) },
        resumes = dto.resumes.map { resumeMapper.mapToDomain(it) }
    )

    /**
     * Maps a [Profile] domain model to a [ProfileDto].
     *
     * @param model The [Profile] domain model to be mapped.
     * @return The mapped [ProfileDto].
     */
    fun mapToDto(model: Profile): ProfileDto = ProfileDto(
        id = model.id,
        firstName = model.firstName,
        lastName = model.lastName,
        email = model.email,
        contactNumber = model.contactNumber,
        headline = model.headline,
        bio = model.bio,
        location = model.location,
        dob = model.dob,
        gender = model.gender,
        skills = model.skills.map { skillMapper.mapToDto(it) },
        educations = model.educations.map { educationMapper.mapToDto(it) },
        experiences = model.experiences.map { experienceMapper.mapToDto(it) },
        certifications = model.certifications.map { certificationMapper.mapToDto(it) },
        resumes = model.resumes.map { resumeMapper.mapToDto(it) }
    )
}