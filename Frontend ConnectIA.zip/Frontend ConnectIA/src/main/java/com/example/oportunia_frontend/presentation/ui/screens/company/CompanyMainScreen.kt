package com.example.oportunia_frontend.presentation.ui.screens.company

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.oportunia_frontend.presentation.navigation.CompanyNavItem
import com.example.oportunia_frontend.presentation.viewmodel.CompanyProfileViewModel

/**
 * Pantalla principal del flujo de empresa.
 * Muestra un BottomBar con 5 ítems: Home, Jobs, Notifs, Cand list, Profile.
 * Según el índice seleccionado, se despliega la pantalla correspondiente:
 *  - CompanyHomeScreen
 *  - CompanyJobsScreen
 *  - CompanyNotificationsScreen
 *  - CompanyCandListScreen
 *  - CompanyProfileScreen
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompanyMainScreen(navController: NavController) {
    // Lista de ítems de la Bottom Bar para empresa
    val bottomNavItems = listOf(
        CompanyNavItem.Home,
        CompanyNavItem.Jobs,
        CompanyNavItem.Candidates,
        CompanyNavItem.Profile
    )

    // Estado para el índice seleccionado
    var selectedItem by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            // TopAppBar dinámico según la pestaña activa
            when (selectedItem) {
                // 0) Company Home
                0 -> {
                    TopAppBar(
                        title = { Text("Home", color = Color.White) },
                        navigationIcon = {
                            IconButton(onClick = { navController.navigate("login") }) {
                                Icon(Icons.Default.ExitToApp, contentDescription = "Back", tint = Color.White, modifier = Modifier
                                    .scale(scaleX = -1f, scaleY = 1f))
                            }
                        },
                        actions = {
                            IconButton(onClick = { navController.navigate("company_notifications_screen") }) {
                                Icon(
                                    Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = Color.White
                                )
                            }
                        },
                        colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF2196F3))
                    )
                }
                // 1) Company Jobs
                1 -> {
                    TopAppBar(
                        title = { Text("Jobs", color = Color.White) },
                        navigationIcon = {
                            IconButton(onClick = { navController.navigate("company_notifications_screen") }) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = "Back",
                                    tint = Color.White
                                )
                            }
                        },
                        actions = {
                            IconButton(onClick = { navController.navigate("company_notifications_screen") }) {
                                Icon(
                                    Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = Color.White
                                )
                            }
                        },
                        colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF2196F3))
                    )
                }

                // 3) Company Candidates
                2 -> {
                    TopAppBar(
                        title = { Text("Candidate List", color = Color.White) },
                        navigationIcon = {
                            IconButton(onClick = { /* sin retroceso */ }) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = "Back",
                                    tint = Color.White
                                )
                            }
                        },
                        actions = {
                            IconButton(onClick = { navController.navigate("company_notifications_screen") }) {
                                Icon(
                                    Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = Color.White
                                )
                            }
                        },
                        colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF2196F3))
                    )
                }
                // 4) Company Profile
                3 -> {
                    TopAppBar(
                        title = { Text("Profile", color = Color.White) },
                        navigationIcon = {
                            IconButton(onClick = { navController.navigate("company_notifications_screen") }) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = "Back",
                                    tint = Color.White
                                )
                            }
                        },
                        actions = {
                            IconButton(onClick = { navController.navigate("company_notifications_screen") })  {
                                Icon(
                                    Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = Color.White
                                )
                            }
                        },
                        colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF2196F3))
                    )
                }
            }
        },
        bottomBar = {
            // Barra inferior con 5 ítems para empresa
            NavigationBar(containerColor = Color.LightGray) {
                bottomNavItems.forEachIndexed { index, item ->
                    NavigationBarItem(
                        icon = { Icon(item.icon, contentDescription = item.title, tint = Color.Black) },
                        label = { Text(item.title, color = Color.Black) },
                        selected = selectedItem == index,
                        onClick = { selectedItem = index }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
        ) {
            // Según el índice seleccionado, se muestra la pantalla correspondiente:
            when (selectedItem) {
                0 -> CompanyHomeScreen(navController)
                1 -> CompanyJobsScreen(navController)
                2 -> CompanyCandListScreen(navController)
                3 -> CompanyProfileScreen(navController)
            }
        }
    }
}
