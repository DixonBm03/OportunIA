package com.example.oportunia_frontend.presentation.ui.screens.students

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavController
import com.example.oportunia_frontend.presentation.navigation.BottomNavItem
import com.example.oportunia_frontend.presentation.viewmodel.JobViewModel
import com.example.oportunia_frontend.presentation.viewmodel.ProfileViewModel


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    navController: NavController,
    profileViewModel: ProfileViewModel,
    jobViewModel: JobViewModel
) {
    val bottomNavItems = listOf(
        BottomNavItem.Home,
        BottomNavItem.Resume,
        BottomNavItem.Jobs,
        BottomNavItem.Interview,
        BottomNavItem.Profile
    )

    var selectedItem by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            when (selectedItem) {
                // 0) Home
                0 -> {
                    TopAppBar(
                        title = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text("Home", color = Color.White)
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = {
                                navController.navigate("login")
                            }) {
                                Icon(Icons.Default.ExitToApp, contentDescription = "Back", tint = Color.White, modifier = Modifier
                                    .scale(scaleX = -1f, scaleY = 1f))
                            }
                        },
                        actions = {
                            IconButton(onClick = { navController.navigate("notifications_screen") }) {
                                Icon(Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = Color.White)
                            }
                        },
                        colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF2196F3))
                    )
                }

                // 1) My Resume
                1 -> {
                    TopAppBar(
                        title = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text("My Resume", color = Color.White)
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = {
                                // navController.popBackStack()
                            }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                            }
                        },
                        actions = {
                            IconButton(onClick = { navController.navigate("notifications_screen") }) {
                                Icon(Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = Color.White)
                            }
                        },
                        colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF2196F3))
                    )
                }

                // 2) Jobs
                2 -> {
                    TopAppBar(
                        title = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text("Jobs", color = Color.White)
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = {
                                // navController.popBackStack()
                            }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                            }
                        },
                        actions = {
                            IconButton(onClick = { navController.navigate("notifications_screen") }) {
                                Icon(Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = Color.White)
                            }
                        },
                        colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF2196F3))
                    )
                }

                // 3) Interview
                3 -> {
                    TopAppBar(
                        title = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text("Interview", color = Color.White)
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = {
                                // navController.popBackStack()
                            }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                            }
                        },
                        actions = {
                            IconButton(onClick = { navController.navigate("notifications_screen") }) {
                                Icon(Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = Color.White)
                            }
                        },
                        colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF2196F3))
                    )
                }

                // 4) Profile
                4 -> {
                    TopAppBar(
                        title = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text("Profile", color = Color.White)
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = {
                                // navController.popBackStack()
                            }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                            }
                        },
                        actions = {
                            IconButton(onClick = { navController.navigate("notifications_screen") }) {
                                Icon(Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = Color.White)
                            }
                        },
                        colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF2196F3))
                    )
                }
            }
        },
        bottomBar = {
            // Barra inferior con 5 ítems
            NavigationBar(containerColor = Color.LightGray) {
                bottomNavItems.forEachIndexed { index, item ->
                    NavigationBarItem(
                        icon = { Icon(item.icon, contentDescription = item.title, tint = Color.Black) },
                        label = { Text(item.title, color = Color.Black) },
                        selected = selectedItem == index,
                        onClick = { selectedItem = index }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (selectedItem) {
                0 -> HomeScreen(navController, profileViewModel)
                1 -> ResumeScreen(navController, jobViewModel)
                2 -> JobsScreen(navController, jobViewModel)
                3 -> InterviewScreen(navController, jobViewModel)
                4 -> ProfileScreen(navController, profileViewModel)
            }
        }
    }
}
