// File: presentation/ui/screens/students/ProfileScreen.kt
package com.example.oportunia_frontend.presentation.ui.screens.students

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.oportunia_frontend.domain.model.Profile
import com.example.oportunia_frontend.presentation.viewmodel.ProfileViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    navController: NavController,
    profileViewModel: ProfileViewModel
) {
    // Cuando se inicia la pantalla, pedimos al ViewModel que cargue el perfil actual:
    LaunchedEffect(Unit) {
        profileViewModel.findProfile()
    }

    // Estado para saber si estamos en modo edición o en modo sólo lectura:
    var isEditing by remember { mutableStateOf(false) }

    // Obtenemos el Profile (dominio) desde el ViewModel:
    val detailProfile by profileViewModel.selectedProfile.collectAsState()

    // Estados locales para cada uno de los campos editables. Inicialmente son nulos:
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var contactNumber by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var headline by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }

    // Cuando cambie detailProfile (luego de la carga del ViewModel),
    // rellenamos nuestros estados locales con los valores actuales:
    LaunchedEffect(detailProfile) {
        detailProfile?.let { profile ->
            firstName = profile.firstName
            lastName = profile.lastName
            email = profile.email
            contactNumber = profile.contactNumber
            location = profile.location
            dob = profile.dob
            gender = profile.gender
            headline = profile.headline
            bio = profile.bio
        }
    }

    // Scrollable container general:
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(Color.White)
            .padding(16.dp)
    ) {
        // ─── Top Row: Título + Edit / Save / Cancel ──────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "My Profile",
                style = MaterialTheme.typography.titleLarge,
                color = Color.Black
            )

            Spacer(modifier = Modifier.weight(1f))

            if (detailProfile != null) {
                if (isEditing) {
                    // En modo edición: mostrar botón Cancelar y botón Guardar:
                    IconButton(
                        onClick = {
                            // Al cancelar, revertimos los campos a los valores del ViewModel:
                            detailProfile?.let { profile ->
                                firstName = profile.firstName
                                lastName = profile.lastName
                                email = profile.email
                                contactNumber = profile.contactNumber
                                location = profile.location
                                dob = profile.dob
                                gender = profile.gender
                                headline = profile.headline
                                bio = profile.bio
                            }
                            isEditing = false
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cancel Edit",
                            tint = Color.Black,
                            modifier = Modifier.size( ThirtySixDp )
                        )
                    }

                    IconButton(
                        onClick = {
                            // Construimos un objeto Profile actualizado:
                            detailProfile?.let { original ->
                                val updated = Profile(
                                    id = original.id,
                                    firstName = firstName.trim(),
                                    lastName = lastName.trim(),
                                    email = email.trim(),
                                    contactNumber = contactNumber.trim(),
                                    headline = headline.trim(),
                                    bio = bio.trim(),
                                    location = location.trim(),
                                    dob = dob.trim(),
                                    gender = gender.trim(),
                                    skills = original.skills,             // Por simplicidad, mantenemos las listas originales
                                    educations = original.educations,
                                    experiences = original.experiences,
                                    certifications = original.certifications,
                                    resumes = original.resumes
                                )
                                // Llamamos al ViewModel para actualizar
                                profileViewModel.updateProfile(updated)
                            }
                            isEditing = false
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Save Profile",
                            tint = Color.Black,
                            modifier = Modifier.size( ThirtySixDp )
                        )
                    }
                } else {
                    // En modo lectura: mostrar sólo el icono Editar
                    IconButton(
                        onClick = { isEditing = true }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Profile",
                            tint = Color.Black,
                            modifier = Modifier.size( ThirtySixDp )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // ─── Si el perfil no está cargado: mostramos un Progress ────────────────
        if (detailProfile == null) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
            return@Column
        }

        // ─── A partir de aquí tenemos el objeto detailProfile no nulo ──────────
        val profile = detailProfile!!

        // ─── Campos de texto: si estamos en modo edición, usamos TextField editables;
        //     si no, simplemente mostramos como texto (ProfileText) ────────────────

        if (isEditing) {
            // ─── MODO EDICIÓN: múltiples OutlinedTextField ─────────────────────────
            OutlinedTextField(
                value = firstName,
                onValueChange = { firstName = it },
                label = { Text("First Name") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            OutlinedTextField(
                value = lastName,
                onValueChange = { lastName = it },
                label = { Text("Last Name") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            OutlinedTextField(
                value = contactNumber,
                onValueChange = { contactNumber = it },
                label = { Text("Contact Number") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            OutlinedTextField(
                value = location,
                onValueChange = { location = it },
                label = { Text("Location") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            OutlinedTextField(
                value = dob,
                onValueChange = { dob = it },
                label = { Text("Date of Birth") },
                placeholder = { Text("YYYY-MM-DD") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            OutlinedTextField(
                value = gender,
                onValueChange = { gender = it },
                label = { Text("Gender") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            OutlinedTextField(
                value = headline,
                onValueChange = { headline = it },
                label = { Text("Headline") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            OutlinedTextField(
                value = bio,
                onValueChange = { bio = it },
                label = { Text("Bio") },
                maxLines = 5,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            )

            // ─── Botones Save / Cancel ya están arriba junto al título ─────────

        } else {
            // ─── MODO LECTURA: mostrar cada campo con ProfileText ─────────────────
            ProfileText(label = "Name", value = "${profile.firstName} ${profile.lastName}")
            ProfileText(label = "Email", value = profile.email)
            ProfileText(label = "Contact", value = profile.contactNumber)
            ProfileText(label = "Location", value = profile.location)
            ProfileText(label = "Date of Birth", value = profile.dob)
            ProfileText(label = "Gender", value = profile.gender)
            ProfileText(label = "Headline", value = profile.headline)
            ProfileText(label = "Bio", value = profile.bio)
        }

        // ─── Secciones de listas (Skills, Education, Experience, Certifications, Resumes)
        //     Para no complicar demasiado, las mostramos siempre en modo lectura.
        //     Si se requiere, se puede extender para editar las listas también.

        Spacer(modifier = Modifier.height(16.dp))
        Section(title = "Skills")
        profile.skills.forEach { skill ->
            ProfileText(
                label = "- ${skill.name}",
                value = "Level: ${skill.level}"
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Section(title = "Education")
        profile.educations.forEach { edu ->
            ProfileText(
                label = "- ${edu.institution}",
                value = "${edu.degree} (${edu.startDate} to ${edu.endDate})"
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Section(title = "Experience")
        profile.experiences.forEach { exp ->
            ProfileText(
                label = "- ${exp.company}",
                value = "${exp.position} (${exp.startDate} to ${exp.endDate})"
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Section(title = "Certifications")
        profile.certifications.forEach { cert ->
            ProfileText(
                label = "- ${cert.name}",
                value = "${cert.issuer} (${cert.date})"
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Section(title = "Resumes")
        profile.resumes.forEach { res ->
            ProfileText(
                label = "- ${res.title}",
                value = res.fileUrl
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun Section(title: String) {
    Spacer(modifier = Modifier.height(8.dp))
    Divider(color = Color.LightGray, thickness = 1.dp)
    Spacer(modifier = Modifier.height(8.dp))
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = Color.Black,
        fontWeight = FontWeight.SemiBold
    )
}

@Composable
private fun ProfileText(label: String, value: String) {
    Column(modifier = Modifier.padding(bottom = 8.dp)) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, style = MaterialTheme.typography.bodyMedium)
    }
}

// Constante para el tamaño del ícono en 36.dp:
private val ThirtySixDp = 36.dp
