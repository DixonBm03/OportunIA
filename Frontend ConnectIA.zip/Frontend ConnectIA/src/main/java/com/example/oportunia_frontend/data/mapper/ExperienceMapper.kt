package com.example.oportunia_frontend.data.mapper

import com.example.oportunia_frontend.data.remote.dto.ExperienceDto
import com.example.oportunia_frontend.domain.model.Experience
import javax.inject.Inject

class ExperienceMapper @Inject constructor(){
    fun mapToDomain(dto: ExperienceDto): Experience = Experience(
        company = dto.company,
        position = dto.position,
        startDate = dto.startDate.orEmpty(),
        endDate = dto.endDate.orEmpty()
    )

    fun mapToDto(model: Experience): ExperienceDto = ExperienceDto(
        company = model.company,
        position = model.position,
        startDate = model.startDate,
        endDate = model.endDate
    )
}