package com.example.oportunia_frontend.domain.repository

import com.example.oportunia_frontend.domain.model.Job

interface JobRepository {
    suspend fun getAllJobs(): Result<List<Job>>
    suspend fun getJobById(id: Long): Result<Job>
}