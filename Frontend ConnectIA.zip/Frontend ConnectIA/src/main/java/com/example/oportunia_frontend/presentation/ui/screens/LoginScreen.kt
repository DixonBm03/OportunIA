package com.example.oportunia_frontend.presentation.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.oportunia_frontend.presentation.viewmodel.LoginViewModel

@Composable
fun LoginScreen(
    navController: NavController,
    loginViewModel: LoginViewModel   // lo mantenemos por si en el futuro quieres usar lógica en ViewModel
) {
    val topBackgroundColor = Color(0xFF2196F3)
    val bottomBackgroundColor = Color(0xFF9E9E9E)
    val loginButtonColor = Color(0xFF4CAF50)
    val linkColor = Color(0xFFFF0000)

    // Estados para el contenido de los campos
    var emailText by remember { mutableStateOf(TextFieldValue("")) }
    var passwordText by remember { mutableStateOf(TextFieldValue("")) }

    // Estado para mensajes de error:
    // - showEmptyWarning: si dejan alguno vacío
    // - showInvalidWarning: si ambos están llenos pero no coinciden con "student"/"student" ni "company"/"company"
    var showEmptyWarning by remember { mutableStateOf(false) }
    var showInvalidWarning by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        // Fondo superior e inferior (sin cambiar)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(topBackgroundColor)
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .padding(top = 200.dp)
                .background(bottomBackgroundColor)
        )

        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Ícono de usuario genérico
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(Color.LightGray),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "User Icon",
                            tint = Color.Black,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Welcome",
                        style = MaterialTheme.typography.headlineLarge,
                        color = Color.Black
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // --- Campo Email ---
                    OutlinedTextField(
                        value = emailText,
                        onValueChange = {
                            emailText = it
                            // Ocultamos advertencias si el usuario escribe de nuevo
                            if (showEmptyWarning) showEmptyWarning = false
                            if (showInvalidWarning) showInvalidWarning = false
                        },
                        label = { Text("Email") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // --- Campo Password ---
                    OutlinedTextField(
                        value = passwordText,
                        onValueChange = {
                            passwordText = it
                            // Ocultamos advertencias si el usuario escribe de nuevo
                            if (showEmptyWarning) showEmptyWarning = false
                            if (showInvalidWarning) showInvalidWarning = false
                        },
                        label = { Text("Password") },
                        modifier = Modifier.fillMaxWidth(),
                        visualTransformation = PasswordVisualTransformation()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // --- Mensaje: si alguno está en blanco ---
                    if (showEmptyWarning) {
                        Text(
                            text = "Por favor completa ambos campos",
                            color = Color.Red,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    // --- Mensaje: si ambos no están vacíos pero no coinciden con credenciales válidas ---
                    if (showInvalidWarning) {
                        Text(
                            text = "Credenciales inválidas",
                            color = Color.Red,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // --- Botón Login ---
                    Button(
                        onClick = {
                            val email = emailText.text.trim()
                            val password = passwordText.text.trim()

                            // 1) Si alguno está en blanco ⇒ advertencia y nada más
                            if (email.isBlank() || password.isBlank()) {
                                showEmptyWarning = true
                                return@Button
                            }

                            // 2) Si es empresa EXACTAMENTE "company"/"company" ⇒ ruta empresa
                            if (email == "company" && password == "company") {
                                navController.navigate("company_main") {
                                    popUpTo("login") { inclusive = true }
                                }
                                return@Button
                            }

                            // 3) Si es estudiante EXACTAMENTE "student"/"student" ⇒ ruta estudiante
                            if (email == "student" && password == "student") {
                                navController.navigate("main") {
                                    popUpTo("login") { inclusive = true }
                                }
                                return@Button
                            }

                            // 4) Cualquier otro par no es válido ⇒ advertencia
                            showInvalidWarning = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = loginButtonColor),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Login")
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Enlace a register (sin cambiar)
                    Text(
                        text = "Don't have an account? Sign in",
                        color = linkColor,
                        modifier = Modifier.clickable {
                            loginViewModel.onRegisterClicked(navController)
                        }
                    )
                }
            }
        }
    }
}
