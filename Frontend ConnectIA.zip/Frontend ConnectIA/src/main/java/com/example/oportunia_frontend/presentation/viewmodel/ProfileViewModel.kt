// presentation/viewmodel/ProfileViewModel.kt
package com.example.oportunia_frontend.presentation.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.oportunia_frontend.domain.model.Profile
import com.example.oportunia_frontend.domain.repository.ProfileRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class ProfileState {
    object Initial : ProfileState()
    object Loading : ProfileState()
    data class Success(val profile: Profile) : ProfileState()
    data object Empty : ProfileState()
    data class Error(val message: String) : ProfileState()
}

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val profileRepository: ProfileRepository
) : ViewModel() {

    private val _profileState = MutableStateFlow<ProfileState>(ProfileState.Initial)
    val profileState = _profileState.asStateFlow()

    private val _selectedProfile = MutableStateFlow<Profile?>(null)
    val selectedProfile = _selectedProfile.asStateFlow()

    fun findProfile() {
        viewModelScope.launch {
            _profileState.value = ProfileState.Loading
            profileRepository.getProfile()
                .onSuccess { profile ->
                    _profileState.value = ProfileState.Success(profile)
                    _selectedProfile.value = profile
                }
                .onFailure { exception ->
                    _profileState.value = ProfileState.Error(exception.message ?: "Unknown error")
                    Log.e("ProfileViewModel", "Error fetching profile: ${exception.message}")
                }
        }
    }

    fun updateProfile(updated: Profile) {
        viewModelScope.launch {
            _profileState.value = ProfileState.Loading
            profileRepository.updateProfile(updated)
                .onSuccess { savedProfile ->
                    _profileState.value = ProfileState.Success(savedProfile)
                    _selectedProfile.value = savedProfile
                }
                .onFailure { exception ->
                    _profileState.value = ProfileState.Error(exception.message ?: "Error updating")
                    Log.e("ProfileViewModel", "Error updating profile: ${exception.message}")
                }
        }
    }
}
