package com.example.oportunia_frontend.domain.model

/**
 * Data class que representa el perfil de un usuario.
 *
 * @property id Identificador único del perfil.
 * @property firstName Nombre de pila.
 * @property lastName Apellido.
 * @property email Correo electrónico.
 * @property contactNumber Número de contacto.
 * @property headline Título profesional o titular del perfil.
 * @property bio Breve biografía o descripción.
 * @property location Ubicación geográfica.
 * @property dob Fecha de nacimiento en formato "YYYY-MM-DD".
 * @property gender Género.
 * @property skills Lista de habilidades.
 */
data class Profile(
    val id: Long,
    val firstName: String,
    val lastName: String,
    val email: String,
    val contactNumber: String,
    val headline: String,
    val bio: String,
    val location: String,
    val dob: String,
    val gender: String,
    val skills: List<Skill>,
    val educations: List<Education>,
    val experiences: List<Experience>,
    val certifications: List<Certification>,
    val resumes: List<Resume>
)