// data/repository/ProfileRepositoryImpl.kt
package com.example.oportunia_frontend.data.repository

import com.example.oportunia_frontend.data.mapper.ProfileMapper
import com.example.oportunia_frontend.data.remote.ProfileRemoteDataSource
import com.example.oportunia_frontend.domain.model.Profile
import com.example.oportunia_frontend.domain.repository.ProfileRepository
import javax.inject.Inject

class ProfileRepositoryImpl @Inject constructor(
    private val profileRemoteDataSource: ProfileRemoteDataSource,
    private val profileMapper: ProfileMapper
) : ProfileRepository {

    override suspend fun getProfile(): Result<Profile> =
        profileRemoteDataSource.getProfiles().map { profiles ->
            // Asumimos que el endpoint GET /profile devuelve una lista y tomamos el primero
            profiles.first().let { profileDto ->
                profileMapper.mapToDomain(profileDto)
            }
        }

    override suspend fun updateProfile(profile: Profile): Result<Profile> {
        // 1) Mapear el objeto de dominio (Profile) a DTO
        val dtoToSend = profileMapper.mapToDto(profile)

        // 2) Llamar al DataSource que envía el PUT/PATCH
        return profileRemoteDataSource.updateProfile(dtoToSend).map { updatedDto ->
            // 3) Una vez que el servidor devuelve el ProfileDto actualizado, convertirlo a dominio
            profileMapper.mapToDomain(updatedDto)
        }
    }
}
