package com.example.oportunia_frontend.data.datasource.dto.application

import com.example.oportunia_frontend.data.remote.dto.OrganizationDto
import com.example.oportunia_frontend.data.remote.dto.OrganizationRepresentativeDto

/**
 * Data class representing a job listing.
 *
 * @property id The unique identifier of the job.
 * @property company The name of the company offering the job.
 * @property title The title of the job position.
 * @property location The location where the job is based.
 * @property salary The salary offered for the job.
 * @property description A brief description of the job role.
 * @property responsibilities The responsibilities expected from the candidate.
 * @property status The current status of the job posting.
 * @property modality The work modality (e.g., Remote, On-Site).
 * @property tags A list of tags or keywords related to the job.
 * @property areas A list of areas or categories the job belongs to.
 * @property level A list representing the required levels or certifications.
 * @property organization (Optional) Detailed information about the organization.
 * @property organizationRepresentative (Optional) Contact information for the organization.
 */
data class JobDto(
    val id: Long,
    val name: String,
    val salary: String,
    val description: String,
    val status: String,
    val modality: String,
    val tags: List<String>,
    val areas: List<String>,
    val level: List<String>,
    val organization: OrganizationDto,
    val organizationRepresentative: OrganizationRepresentativeDto
)
