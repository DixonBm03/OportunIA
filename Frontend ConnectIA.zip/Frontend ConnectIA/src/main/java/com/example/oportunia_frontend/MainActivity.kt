package com.example.oportunia_frontend

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.ExperimentalMaterial3Api
import com.example.oportunia_frontend.presentation.navigation.MyApp
import com.example.oportunia_frontend.presentation.viewmodel.JobViewModel
import com.example.oportunia_frontend.presentation.viewmodel.LoginViewModel
import com.example.oportunia_frontend.presentation.viewmodel.ProfileViewModel
import com.example.oportunia_frontend.presentation.viewmodel.RegisterViewModel
import com.example.oportunia_frontend.ui.theme.OportuniafrontendTheme
import dagger.hilt.android.AndroidEntryPoint

@OptIn(ExperimentalMaterial3Api::class)
/**
 * Main activity that serves as the entry point for the application.
 * Initializes the TaskViewModel and sets up the Compose UI with the main screen.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val jobViewModel: JobViewModel by viewModels()
    private val profileViewModel: ProfileViewModel by viewModels()
    private val loginViewModel: LoginViewModel by viewModels()
    private val registerViewModel: RegisterViewModel by viewModels()

    /**
     * Initializes the activity and sets up the Compose UI hierarchy.
     *
     * @param savedInstanceState Previously saved instance state, or null if fresh start
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContent {
                OportuniafrontendTheme {
                    MyApp(loginViewModel, registerViewModel, profileViewModel, jobViewModel)
                }
            }
        } catch (e: Exception) {
            Log.e("MainActivity", "Crash: ${e.stackTraceToString()}")
            finish()
        }
    }
}