package com.example.oportunia_frontend.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.navigation.NavController
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor() : ViewModel() {

    /**
     * - Si email/password están vacíos, no navega.
     * - Si email=="company" y password=="company", navega a “company_main”.
     * - En cualquier otro caso (campos no vacíos), navega a “main” (estudiante).
     */
    fun onLoginClicked(
        navController: NavController,
        email: String,
        password: String
    ) {
        // 1) Validar que no estén vacíos
        if (email.isBlank() || password.isBlank()) {
            // No navegamos: simplemente retornamos.
            return
        }

        // 2) Si es exactamente “company”/“company”, vamos al flujo de empresa
        if (email == "company" && password == "company") {
            navController.navigate("company_main") {
                popUpTo("login") { inclusive = true }
            }
        } else {
            // 3) Si no, vamos al flujo de estudiante
            navController.navigate("main") {
                popUpTo("login") { inclusive = true }
            }
        }
    }

    fun onRegisterClicked(navController: NavController) {
        navController.navigate("register")
    }
}
