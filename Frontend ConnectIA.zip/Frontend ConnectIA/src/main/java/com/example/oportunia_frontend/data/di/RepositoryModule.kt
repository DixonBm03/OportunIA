// data/di/RepositoryModule.kt
package com.example.oportunia_frontend.data.di

import com.example.oportunia_frontend.data.repository.JobRepositoryImpl
import com.example.oportunia_frontend.data.repository.ProfileRepositoryImpl
import com.example.oportunia_frontend.domain.repository.JobRepository
import com.example.oportunia_frontend.domain.repository.ProfileRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindJobRepository(
        jobRepositoryImpl: JobRepositoryImpl
    ): JobRepository

    @Binds
    @Singleton
    abstract fun bindProfileRepository(
        profileRepositoryImpl: ProfileRepositoryImpl
    ): ProfileRepository
}
