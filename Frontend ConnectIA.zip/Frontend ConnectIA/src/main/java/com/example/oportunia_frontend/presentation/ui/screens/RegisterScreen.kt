package com.example.oportunia_frontend.presentation.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.oportunia_frontend.presentation.viewmodel.RegisterViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(
    navController: NavController,
    registerViewModel: RegisterViewModel
) {
    val topBackgroundColor = Color(0xFF2196F3)    // Azul superior
    val bottomBackgroundColor = Color(0xFF9E9E9E) // Gris inferior
    val registerButtonColor = Color(0xFF4CAF50)   // Verde del botón "Register"

    val scrollState = rememberScrollState()

    var selectedType by remember {
        mutableStateOf(registerViewModel.selectedType)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .background(topBackgroundColor)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .padding(top = 180.dp)
                .background(bottomBackgroundColor)
        )

        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Box {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .offset(y = (-20).dp)
                            .align(Alignment.TopCenter)
                            .clip(CircleShape)
                            .background(Color.LightGray),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "User Icon",
                            tint = Color.Black,
                            modifier = Modifier.size(15.dp)
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 48.dp, start = 24.dp, end = 24.dp, bottom = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Register",
                            style = MaterialTheme.typography.headlineLarge,
                            color = Color.Black
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        // Campo de Email
                        OutlinedTextField(
                            value = registerViewModel.email,
                            onValueChange = { registerViewModel.onEmailChanged(it) },
                            label = { Text("Email") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Campo de Password
                        OutlinedTextField(
                            value = registerViewModel.password,
                            onValueChange = { registerViewModel.onPasswordChanged(it) },
                            label = { Text("Password") },
                            modifier = Modifier.fillMaxWidth(),
                            visualTransformation = PasswordVisualTransformation()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Campo de Confirmar Password
                        OutlinedTextField(
                            value = registerViewModel.confirmPassword,
                            onValueChange = { registerViewModel.onConfirmPasswordChanged(it) },
                            label = { Text("Confirm Password") },
                            modifier = Modifier.fillMaxWidth(),
                            visualTransformation = PasswordVisualTransformation()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // ========== RadioButtons para "Type" ==========
                        Text(
                            text = "Select Type",
                            style = MaterialTheme.typography.titleMedium
                        )

                        // Coloca ambas opciones en una fila
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Radio para "Student"
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = (selectedType == "Student"),
                                    onClick = {
                                        selectedType = "Student"
                                        registerViewModel.onTypeSelected("Student")
                                    }
                                )
                                Text("Student")
                            }

                            Spacer(modifier = Modifier.width(32.dp))

                            // Radio para "Organization"
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = (selectedType == "Organization Representative"),
                                    onClick = {
                                        selectedType = "Organization Representative"
                                        registerViewModel.onTypeSelected("Organization Representative")
                                    }
                                )
                                Text("Organization")
                            }
                        }
                        // ========== Fin RadioButtons ==========

                        Spacer(modifier = Modifier.height(16.dp))

                        // Botón "Register"
                        Button(
                            onClick = { registerViewModel.onRegisterClicked(navController) },
                            colors = ButtonDefaults.buttonColors(containerColor = registerButtonColor)
                        ) {
                            Text("Register")
                        }
                    }
                }
            }
        }
    }
}