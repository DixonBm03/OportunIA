package com.example.oportunia_frontend.domain.error

/**
 * A sealed class representing different types of errors that can occur in the domain layer.
 * Each specific error class (e.g., TaskError, NetworkError) represents a distinct error type.
 */
sealed class DomainError(
    override val message: String,
    override val cause: Throwable? = null
) : Exception(message, cause) {

    /**
     * Represents an error when a task cannot be completed successfully.
     */
    class TaskError(
        message: String,
        cause: Throwable? = null
    ) : DomainError(message, cause)

    /**
     * Represents a network-related error, such as failure to connect or timeouts.
     */
    class NetworkError(
        message: String,
        cause: Throwable? = null
    ) : DomainError(message, cause)

    /**
     * Represents an error related to issues during the mapping process, such as DTO to domain model mapping failures.
     */
    class MappingError(
        message: String,
        cause: Throwable? = null
    ) : DomainError(message, cause)

    /**
     * Represents an unknown error that doesn't fall into any of the other categories.
     * Provides a default message if no message is provided.
     */
    class UnknownError(
        message: String = "An unknown error occurred",
        cause: Throwable? = null
    ) : DomainError(message, cause)
}