package com.example.oportunia_frontend.data.mapper

import com.example.oportunia_frontend.data.remote.dto.SkillDto
import com.example.oportunia_frontend.domain.model.Skill
import javax.inject.Inject

/**
 * Mapper class for converting between [SkillDto] and [Skill] domain models.
 * This class is currently not active as the methods are commented out.
 */
class SkillMapper @Inject constructor() {

    /**
     * Maps a [SkillDto] to a [Skill] domain model.
     *
     * @param dto The [SkillDto] to be mapped.
     * @return The mapped [Skill] domain model.
     */
    fun mapToDomain(dto: SkillDto): Skill = Skill(
        name = dto.name,
        level = dto.level
    )

    /**
     * Maps a [Skill] domain model to a [SkillDto].
     *
     * @param model The [Skill] domain model to be mapped.
     * @return The mapped [SkillDto].
     */
    fun mapToDto(model: Skill): SkillDto = SkillDto(
        name = model.name,
        level = model.level
    )
}