package com.example.oportunia_frontend.domain.model

data class OrganizationRepresentative (
    val name: String,
    val position: String,
    val email: String
)