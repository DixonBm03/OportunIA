package com.example.oportunia_frontend.data.remote.dto

/**
 * Data class que representa el perfil de un usuario.
 *
 * @property id Identificador único del perfil.
 * @property firstName Nombre de pila.
 * @property lastName Apellido.
 * @property email Correo electrónico.
 * @property contactNumber Número de contacto.
 * @property headline Título profesional o titular del perfil.
 * @property bio Breve biografía o descripción.
 * @property location Ubicación geográfica.
 * @property dob Fecha de nacimiento en formato "YYYY-MM-DD".
 * @property gender Género.
 * @property skills Lista de habilidades.
 */
data class ProfileDto(
    val id: Long,
    val firstName: String,
    val lastName: String,
    val email: String,
    val contactNumber: String,
    val headline: String,
    val bio: String,
    val location: String,
    val dob: String,
    val gender: String,
    val skills: List<SkillDto>,
    val educations: List<EducationDto>,
    val experiences: List<ExperienceDto>,
    val certifications: List<CertificationDto>,
    val resumes: List<ResumeDto>
)