// File: domain/repository/CompanyProfileRepository.kt
package com.example.oportunia_frontend.domain.repository

import com.example.oportunia_frontend.domain.model.CompanyProfile

/**
 * Interfaz que describe las operaciones sobre el perfil de la empresa.
 * En un futuro, su implementación hará llamadas a tu API real.
 */
interface CompanyProfileRepository {
    suspend fun getCompanyProfile(): Result<CompanyProfile>
    suspend fun updateCompanyProfile(profile: CompanyProfile): Result<CompanyProfile>
}
