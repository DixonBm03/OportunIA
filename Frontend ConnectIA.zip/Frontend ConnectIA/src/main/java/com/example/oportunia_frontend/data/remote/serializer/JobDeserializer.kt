package com.example.oportunia_frontend.data.remote.serializer

import com.example.oportunia_frontend.data.datasource.dto.application.JobDto
import com.example.oportunia_frontend.data.remote.dto.OrganizationDto
import com.example.oportunia_frontend.data.remote.dto.OrganizationRepresentativeDto
import com.google.gson.*
import java.lang.reflect.Type
import java.util.*
//Dixon Bustos Medina
class JobDeserializer : JsonDeserializer<JobDto> {
    override fun deserialize(
        json: JsonElement,
        typeOfT: Type,
        context: JsonDeserializationContext
    ): JobDto {

        val jsonObject = json.asJsonObject

        val id = try {
            jsonObject.get("id").asLong
        } catch (e: NumberFormatException) {
            jsonObject.get("id").asString.toLong()
        }

        val name = jsonObject.get("name").asString
        val salary = jsonObject.get("salary").asString
        val description = jsonObject.get("description").asString
        val status = jsonObject.get("status").asString
        val modality = jsonObject.get("modality").asString

        val tags = jsonObject.get("tags").asJsonArray.map { it.asString }
        val areas = jsonObject.get("areas").asJsonArray.map { it.asString }
        val level = jsonObject.get("level").asJsonArray.map { it.asString }

        val organization = context.deserialize<OrganizationDto>(
            jsonObject.get("Organization"),
            OrganizationDto::class.java
        )

        val organizationRepresentative = context.deserialize<OrganizationRepresentativeDto>(
            jsonObject.get("OrganizationRepresentative"),
            OrganizationRepresentativeDto::class.java
        )

        return JobDto(
            id = id,
            name = name,
            salary = salary,
            description = description,
            status = status,
            modality = modality,
            tags = tags,
            areas = areas,
            level = level,
            organization = organization,
            organizationRepresentative = organizationRepresentative
        )
    }
}