// data/remote/api/ProfileService.kt
package com.example.oportunia_frontend.data.remote.api

import com.example.oportunia_frontend.data.remote.dto.ProfileDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.PUT
import retrofit2.http.Path

interface ProfileService {
    @GET("profile")
    suspend fun getProfiles(): Response<List<ProfileDto>>

    /**
     * Actualiza el perfil con id = {id}. Se envía el ProfileDto completo en el body y el servidor
     * devuelve el ProfileDto actualizado.
     */
    @PUT("profile/{id}")
    suspend fun updateProfile(
        @Path("id") id: Long,
        @Body profileDto: ProfileDto
    ): Response<ProfileDto>
}
