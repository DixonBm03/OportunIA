package com.example.oportunia_frontend.data.remote.dto

data class SkillDto (
    val name: String,
    val level: String
)