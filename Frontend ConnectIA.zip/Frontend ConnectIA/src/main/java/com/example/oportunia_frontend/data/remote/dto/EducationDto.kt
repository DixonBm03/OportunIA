package com.example.oportunia_frontend.data.remote.dto

data class EducationDto(
    val institution: String,
    val degree: String,
    val startDate: String,
    val endDate: String
)
