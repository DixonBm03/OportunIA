// domain/repository/ProfileRepository.kt
package com.example.oportunia_frontend.domain.repository

import com.example.oportunia_frontend.domain.model.Profile

interface ProfileRepository {
    suspend fun getProfile(): Result<Profile>

    /**
     * Actualiza el perfil completo del usuario.
     * Recibe un objeto [Profile] con todos los campos (incluyendo el `id`).
     * Devuelve Result<Profile> con el perfil actualizado (tal como lo devuelve el servidor).
     */
    suspend fun updateProfile(profile: Profile): Result<Profile>
}
