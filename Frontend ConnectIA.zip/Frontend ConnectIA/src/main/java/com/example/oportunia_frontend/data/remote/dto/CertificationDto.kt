package com.example.oportunia_frontend.data.remote.dto

data class CertificationDto(
    val name: String,
    val issuer: String,
    val date: String
)
