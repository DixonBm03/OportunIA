// File: CompanyCandListScreen.kt
package com.example.oportunia_frontend.presentation.ui.screens.company

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController

/**
 * Modelo de candidato con toda la información necesaria.
 *
 * @param id Identificador único del candidato
 * @param name Nombre completo del candidato
 * @param role Rol/Título profesional del candidato
 * @param appliedPosition Puesto concreto al que este candidato aplicó
 * @param profileSummary Breve descripción de su perfil (usado aquí como “contenido del CV”)
 * @param cvUrl URL al PDF de su CV (en caso de necesitar un Link externo)
 */
data class Candidate(
    val id: Long,
    val name: String,
    val role: String,
    val appliedPosition: String,
    val profileSummary: String,
    val cvUrl: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompanyCandListScreen(navController: NavController) {
    // 1) Creamos dos candidatos de ejemplo
    val candidates = listOf(
        Candidate(
            id = 1L,
            name = "Dixon Bustos Medina",
            role = "Web Developer & Systems Eng Student",
            appliedPosition = "Software Developer",
            profileSummary = """
                • Full Stack Web Developer con experiencia en:
                  – React + Node.js + MongoDB  
                  – Automatización de pruebas  
                  – Análisis forense digital  
                  – Pentesting básico  

                • Educación:
                  – Licenciatura en Ingeniería de Sistemas (Universidad X)
                  – Cursos en Frontend avanzado (React), Backend (Node.js)  

                • Experiencia Laboral:
                  – Prácticas en Empresa ABC como Desarrollador Frontend (6 meses)
                  – Proyecto universitario: “Plataforma e-commerce con React y Firebase”  

                • Certificaciones:
                  – Certificado “Fundamentos de React” (Platzi)
                  – Certificado “Seguridad Informática” (Coursera)  

                • Idiomas:
                  – Español (Nativo)
                  – Inglés (Intermedio)
            """.trimIndent(),
            cvUrl = "https://www.example.com/dixon_bustos_cv.pdf"
        ),
        Candidate(
            id = 2L,
            name = "María Pérez González",
            role = "Data Analyst & BI Enthusiast",
            appliedPosition = "Data Analyst",
            profileSummary = """
                • Data Analyst con habilidades en:
                  – Python (Pandas, NumPy, Matplotlib)  
                  – SQL (PostgreSQL, MySQL)  
                  – Tableau / Power BI  
                  – Proyectos de machine learning supervisado  

                • Educación:
                  – Ingeniería en Estadística (Universidad Y)
                  – Especialización en Business Intelligence (Universidad Z)  

                • Experiencia Laboral:
                  – Prácticas en Empresa DEF como Analista Junior (4 meses)
                  – Proyecto “Análisis de datos de ventas para e-commerce”  

                • Certificaciones:
                  – Certificado “Data Science with Python” (Udemy)
                  – Certificado “SQL Avanzado” (edX)  

                • Idiomas:
                  – Español (Nativo)
                  – Inglés (Avanzado)
            """.trimIndent(),
            cvUrl = "https://www.example.com/maria_perez_cv.pdf"
        )
    )

    // 2) Estado para saber qué candidato está “expandido” (null = ninguno)
    var expandedCandidateId by remember { mutableStateOf<Long?>(null) }
    // 3) Estado para saber si mostramos el diálogo emergente del CV, y para qué candidato
    var showCvDialogFor by remember { mutableStateOf<Candidate?>(null) }

    Scaffold { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            items(candidates) { candidate ->
                // Cada item es un ListItem “clickable” que alterna expandido/colapsado
                ListItem(
                    headlineContent = { Text(text = candidate.name) },
                    supportingContent = { Text(text = candidate.role) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            expandedCandidateId = if (expandedCandidateId == candidate.id) {
                                null
                            } else {
                                candidate.id
                            }
                        }
                        .padding(vertical = 8.dp, horizontal = 16.dp)
                )

                // Si este candidato está expandido, mostramos los detalles justo debajo:
                if (expandedCandidateId == candidate.id) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 32.dp, end = 16.dp, bottom = 12.dp)
                    ) {
                        // — Puesto al que aplicó —
                        Text(
                            text = "Applied for: ${candidate.appliedPosition}",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        // — Perfil breve de candidato —
                        Text(
                            text = "Profile Summary:",
                            style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                        )
                        Text(
                            text = candidate.profileSummary,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        )

                        // — Botón “Download CV” —
                        Button(
                            onClick = {
                                showCvDialogFor = candidate
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        ) {
                            Text(text = "Download CV")
                        }
                    }
                }

                Divider()
            }
        }

        // 4) Ventana emergente (Dialog) para mostrar el “CV” con diseño agradable
        if (showCvDialogFor != null) {
            val candidate = showCvDialogFor!!
            Dialog(
                onDismissRequest = { showCvDialogFor = null }
            ) {
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    tonalElevation = 8.dp,
                    modifier = Modifier
                        .fillMaxWidth(0.90f)
                        .wrapContentHeight()
                ) {
                    Column(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(16.dp)
                    ) {
                        // Título del diálogo
                        Text(
                            text = "Curriculum Vitae",
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Nombre del candidato
                        Text(
                            text = candidate.name,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                        // Rol/título del candidato
                        Text(
                            text = candidate.role,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.Gray,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        Divider(color = Color.LightGray, thickness = 1.dp)
                        Spacer(modifier = Modifier.height(8.dp))

                        // Contenido del CV en una columna con scroll
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 360.dp) // limitar alto
                                .verticalScroll(rememberScrollState())
                        ) {
                            // 1) Applied Position
                            Text(
                                text = "Applied Position:",
                                style = MaterialTheme.typography.titleSmall,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                            Text(
                                text = candidate.appliedPosition,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )

                            // 2) Profile Summary (texto multilínea)
                            Text(
                                text = "Profile Summary:",
                                style = MaterialTheme.typography.titleSmall,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                            Text(
                                text = candidate.profileSummary,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )

                            // 3) CV URL (en caso de que quieras un link externo)
                            Text(
                                text = "CV URL:",
                                style = MaterialTheme.typography.titleSmall,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                            Text(
                                text = candidate.cvUrl,
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.primary)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Botón de “Close” al final del diálogo
                        Button(
                            onClick = { showCvDialogFor = null },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                        ) {
                            Text(text = "Close")
                        }
                    }
                }
            }
        }
    }
}
