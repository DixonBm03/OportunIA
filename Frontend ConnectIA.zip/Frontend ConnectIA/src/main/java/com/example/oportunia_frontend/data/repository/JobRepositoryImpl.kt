package com.example.oportunia_frontend.data.repository

import com.example.oportunia_frontend.data.mapper.JobMapper
import com.example.oportunia_frontend.data.remote.JobRemoteDataSource
import com.example.oportunia_frontend.domain.model.Job
import com.example.oportunia_frontend.domain.repository.JobRepository
import java.net.UnknownHostException
import javax.inject.Inject

/**
 * Implementation of [JobRepository] that handles job data operations.
 * This repository acts as a single source of truth for job data,
 * coordinating between remote data sources and mapping DTOs to domain models.
 *
 * @property jobRemoteDataSource Data source for remote task operations
 * @property jobMapper Mapper for converting between DTO and domain models
 */
class JobRepositoryImpl @Inject constructor(
    private val jobRemoteDataSource: JobRemoteDataSource,
    private val jobMapper: JobMapper
) : JobRepository {

    override suspend fun getAllJobs(): Result<List<Job>> {
        return try {
            jobRemoteDataSource.getAllJobs().map { jobsDto ->
                jobMapper.mapToDomainList(jobsDto)
            }
        } catch (e: UnknownHostException) {
            Result.failure(Exception("Network error: Cannot connect to server. Please check your internet connection."))
        } catch (e: Exception) {
            Result.failure(Exception("Error fetching jobs: ${e.message}"))
        }
    }

    override suspend fun getJobById(id: Long): Result<Job> =
        jobRemoteDataSource.getJobById(id).map { jobDto ->
            jobMapper.mapToDomain(jobDto)
        }
}