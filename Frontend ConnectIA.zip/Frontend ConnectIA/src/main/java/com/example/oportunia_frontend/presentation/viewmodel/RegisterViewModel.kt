package com.example.oportunia_frontend.presentation.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.navigation.NavController
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class RegisterViewModel @Inject constructor() : ViewModel() {

    /**
     * Current email input value.
     * Can only be modified via [onEmailChanged].
     */
    var email by mutableStateOf("")
        private set

    /**
     * Current password input value.
     * Can only be modified via [onPasswordChanged].
     */
    var password by mutableStateOf("")
        private set

    /**
     * Current password confirmation input value.
     * Can only be modified via [onConfirmPasswordChanged].
     */
    var confirmPassword by mutableStateOf("")
        private set

    /**
     * Currently selected user type.
     * Can only be modified via [onTypeSelected].
     * Defaults to "Options".
     */
    var selectedType by mutableStateOf("Options")
        private set

    /**
     * Updates the email value.
     * @param newEmail The new email input value
     */
    fun onEmailChanged(newEmail: String) {
        email = newEmail
    }

    /**
     * Updates the password value.
     * @param newPassword The new password input value
     */
    fun onPasswordChanged(newPassword: String) {
        password = newPassword
    }

    /**
     * Updates the password confirmation value.
     * @param newConfirmPassword The new confirmation password value
     */
    fun onConfirmPasswordChanged(newConfirmPassword: String) {
        confirmPassword = newConfirmPassword
    }

    /**
     * Updates the selected user type.
     * @param newType The newly selected user type
     */
    fun onTypeSelected(newType: String) {
        selectedType = newType
    }

    /**
     * Handles register button click.
     * Navigates to login screen and clears back stack.
     * @param navController Navigation controller for screen transitions
     */
    fun onRegisterClicked(navController: NavController) {
        navController.navigate("login") {
            popUpTo("register") { inclusive = true }
        }
    }
}