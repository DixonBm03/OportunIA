package com.example.oportunia_frontend.data.mapper

import com.example.oportunia_frontend.data.remote.dto.OrganizationDto
import com.example.oportunia_frontend.domain.model.Organization
import javax.inject.Inject

class OrganizationMapper @Inject constructor() {

    /**
     * Maps an [OrganizationDto] to an [Organization] domain model.
     *
     * @param dto The [OrganizationDto] to be mapped.
     * @return The mapped [Organization] domain model.
     */
    fun mapToDomain(dto: OrganizationDto): Organization = Organization(
        name = dto.name,
        website = dto.website,
        location = dto.location
    )

    /**
     * Maps an [Organization] domain model to an [OrganizationDto].
     *
     * @param model The [Organization] domain model to be mapped.
     * @return The mapped [OrganizationDto].
     */
    fun mapToDto(model: Organization): OrganizationDto = OrganizationDto(
        name = model.name,
        website = model.website,
        location = model.location
    )
}