package com.example.oportunia_frontend.data.remote.serializer

import com.example.oportunia_frontend.data.remote.dto.*
import com.google.gson.JsonDeserializer
import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonElement
import java.lang.reflect.Type

class ProfileDeserializer : JsonDeserializer<ProfileDto> {
    override fun deserialize(
        json: JsonElement,
        typeOfT: Type,
        context: JsonDeserializationContext
    ): ProfileDto {
        val jsonObject = json.asJsonObject

        val id = try {
            jsonObject.get("id").asLong
        } catch (e: NumberFormatException) {
            jsonObject.get("id").asString.toLong()
        }

        val userId = jsonObject.get("userId").asInt
        val firstName = jsonObject.get("firstName").asString
        val lastName = jsonObject.get("lastName").asString
        val email = jsonObject.get("email").asString
        val contactNumber = jsonObject.get("contactNumber").asString
        val headline = jsonObject.get("headline").asString
        val bio = jsonObject.get("bio").asString
        val location = jsonObject.get("location").asString
        val dob = jsonObject.get("dob").asString
        val gender = jsonObject.get("gender").asString

        val skills = jsonObject.getAsJsonArray("skills").map {
            context.deserialize<SkillDto>(it, SkillDto::class.java)
        }

        val educations = jsonObject.getAsJsonArray("educations").map {
            context.deserialize<EducationDto>(it, EducationDto::class.java)
        }

        val experiences = jsonObject.getAsJsonArray("experiences").map {
            context.deserialize<ExperienceDto>(it, ExperienceDto::class.java)
        }

        val certifications = jsonObject.getAsJsonArray("certifications").map {
            context.deserialize<CertificationDto>(it, CertificationDto::class.java)
        }

        val resumes = jsonObject.getAsJsonArray("resumes").map {
            context.deserialize<ResumeDto>(it, ResumeDto::class.java)
        }

        return ProfileDto(
            id = id,
            firstName = firstName,
            lastName = lastName,
            email = email,
            contactNumber = contactNumber,
            headline = headline,
            bio = bio,
            location = location,
            dob = dob,
            gender = gender,
            skills = skills,
            educations = educations,
            experiences = experiences,
            certifications = certifications,
            resumes = resumes
        )
    }
}
