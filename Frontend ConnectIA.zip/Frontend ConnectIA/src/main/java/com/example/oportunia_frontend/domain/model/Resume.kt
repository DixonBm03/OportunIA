package com.example.oportunia_frontend.domain.model

data class Resume(
    val title: String,
    val fileUrl: String
)
