package com.example.oportunia_frontend.presentation.ui.screens.company

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

// Modelo de datos para cada notificación
data class CompanyNotif(val type: IconType, val text: String, val time: String)

// Tipos de icono que usaremos para decidir qué icono dibujar
enum class IconType { STAR, AVATAR, HEART }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompanyNotificationsScreen(navController: NavController) {
    // Lista de pestañas (tabs) y estado de cuál está seleccionado
    val tabs = listOf("All", "Applications", "Stats")
    var selectedTab by remember { mutableStateOf(tabs.first()) }

    // Datos de ejemplo (mock)
    val allNotifs = listOf(
        CompanyNotif(IconType.STAR,   "You have new applicants.",                       "5m"),
        CompanyNotif(IconType.AVATAR, "Arnoldo applied to \"Software Developer\".",    "10m"),
        CompanyNotif(IconType.HEART,  "You appeared in over +545 searches.",           "30m")
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Notifications", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF2196F3))
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Row de pestañas (horizontal scroll)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 8.dp, horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                tabs.forEach { tab ->
                    FilterChip(
                        selected = (tab == selectedTab),
                        onClick = { selectedTab = tab },
                        label = { Text(tab) }
                    )
                }
            }

            Divider()

            // Filtrar la lista según pestaña seleccionada
            val itemsToShow = when (selectedTab) {
                "Applications" -> allNotifs.filter { it.type == IconType.AVATAR }
                "Stats"        -> allNotifs.filter { it.type == IconType.HEART }
                else           -> allNotifs
            }

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(itemsToShow) { notif ->
                    CompanyNotifRow(notif)
                    Divider()
                }
            }
        }
    }
}

@Composable
private fun CompanyNotifRow(n: CompanyNotif) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Icono de acuerdo al tipo
        when (n.type) {
            IconType.STAR -> {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = Color.Black
                )
            }
            IconType.AVATAR -> {
                // Si quisieras usar una imagen de avatar concreta, la puedes reemplazar aquí.
                // Como ejemplo usamos el icono de Person. Si tienes un R.drawable de avatar real, sustitúyelo.
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = Color.Black
                )
            }
            IconType.HEART -> {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = null,
                    tint = Color.Black
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = n.text,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Black
            )
        }

        Text(
            text = n.time,
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray
        )
    }
}
