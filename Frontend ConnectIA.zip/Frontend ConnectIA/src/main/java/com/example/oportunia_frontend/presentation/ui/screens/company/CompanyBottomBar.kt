package com.example.oportunia_frontend.presentation.ui.screens.company

import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.example.oportunia_frontend.presentation.navigation.CompanyNavItem

@Composable
fun CompanyBottomBar(
    selected: Int,
    onSelected: (Int) -> Unit
) {
    // Ahora sí es sólo una lista de objetos ya definidos
    val items = listOf(
        CompanyNavItem.Home,
        CompanyNavItem.Jobs,
        CompanyNavItem.Candidates,
        CompanyNavItem.Profile
    )

    NavigationBar {
        items.forEachIndexed { idx, item ->
            NavigationBarItem(
                icon        = { Icon(item.icon, contentDescription = item.title) },
                label       = { Text(item.title) },
                selected    = idx == selected,
                onClick     = { onSelected(idx) }
            )
        }
    }
}
