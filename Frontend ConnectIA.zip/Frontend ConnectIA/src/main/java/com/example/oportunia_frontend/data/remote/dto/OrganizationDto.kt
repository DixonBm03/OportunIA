package com.example.oportunia_frontend.data.remote.dto

/**
 * Data class representing an organization.
 * Contains details about an organization, including its name, type, description, contact information,
 * location, year founded, industry, and associated URLs, jobs, and representatives.
 *
 * @property name The name of the organization.
 * @property website
 * @property location
 */
data class OrganizationDto(
    val name: String,
    val website: String,
    val location: String
)