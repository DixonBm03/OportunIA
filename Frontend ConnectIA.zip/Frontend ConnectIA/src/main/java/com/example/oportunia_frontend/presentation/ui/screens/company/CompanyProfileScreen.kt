// File: presentation/ui/screens/company/CompanyProfileScreen.kt
package com.example.oportunia_frontend.presentation.ui.screens.company

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.oportunia_frontend.domain.model.CompanyProfile
import com.example.oportunia_frontend.presentation.viewmodel.CompanyProfileViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompanyProfileScreen(
    navController: NavController
) {
    // 1) Obtenemos el ViewModel localmente, sin Hilt
    val viewModel: CompanyProfileViewModel = viewModel()

    // 2) Al entrar a la pantalla solicitamos cargar los datos
    LaunchedEffect(Unit) {
        viewModel.fetchCompanyProfile()
    }

    // 3) Estado actual del perfil (puede ser null mientras carga)
    val companyProfileState by viewModel.companyProfile.collectAsState()

    // 4) Bandera para alternar entre modo lectura y edición
    var isEditing by remember { mutableStateOf(false) }

    // 5) Variables locales para editar cada campo
    var name by remember { mutableStateOf("") }
    var founded by remember { mutableStateOf("") }
    var globalPresence by remember { mutableStateOf("") }
    var innovativeProducts by remember { mutableStateOf("") }
    var rAndDInvestment by remember { mutableStateOf("") }
    var enterpriseSolutions by remember { mutableStateOf("") }
    var mission by remember { mutableStateOf("") }

    // 6) Cuando el StateFlow se actualice, volcamos en las variables locales
    LaunchedEffect(companyProfileState) {
        companyProfileState?.let { perfil ->
            name = perfil.name
            founded = perfil.founded
            globalPresence = perfil.globalPresence
            innovativeProducts = perfil.innovativeProducts
            rAndDInvestment = perfil.rAndDInvestment
            enterpriseSolutions = perfil.enterpriseSolutions
            mission = perfil.mission
        }
    }

    // 7) Contenedor principal
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(Color(0xFFF5F5F5))
            .padding(16.dp)
    ) {
        // ─── Fila superior con título y acción de editar/guardar/cancelar ──────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Company Profile",
                style = MaterialTheme.typography.titleLarge,
                color = Color(0xFF212121),
                modifier = Modifier.weight(1f)
            )

            if (companyProfileState != null) {
                if (isEditing) {
                    // Botón “Cancelar”: restaura valores originales y vuelve a modo lectura
                    IconButton(onClick = {
                        companyProfileState?.let { original ->
                            name = original.name
                            founded = original.founded
                            globalPresence = original.globalPresence
                            innovativeProducts = original.innovativeProducts
                            rAndDInvestment = original.rAndDInvestment
                            enterpriseSolutions = original.enterpriseSolutions
                            mission = original.mission
                        }
                        isEditing = false
                    }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cancelar edición",
                            tint = Color(0xFF424242)
                        )
                    }
                    // Botón “Guardar”: actualiza en ViewModel y vuelve a modo lectura
                    IconButton(onClick = {
                        val updatedProfile = CompanyProfile(
                            id = companyProfileState!!.id,
                            name = name.trim(),
                            founded = founded.trim(),
                            globalPresence = globalPresence.trim(),
                            innovativeProducts = innovativeProducts.trim(),
                            rAndDInvestment = rAndDInvestment.trim(),
                            enterpriseSolutions = enterpriseSolutions.trim(),
                            mission = mission.trim()
                        )
                        viewModel.updateCompanyProfile(updatedProfile)
                        isEditing = false
                    }) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Guardar cambios",
                            tint = Color(0xFF424242)
                        )
                    }
                } else {
                    // Botón “Editar”: cambia a modo edición
                    IconButton(onClick = { isEditing = true }) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Editar perfil",
                            tint = Color(0xFF424242)
                        )
                    }
                }
            }
        }

        // ─── Mostrar loader si aún no llegó el perfil ───────────────────────────
        if (companyProfileState == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
            return@Column
        }

        // ─── A partir de aquí, companyProfileState ya no es null ──────────────────
        val profile: CompanyProfile = companyProfileState!!

        if (isEditing) {
            // ─── Modo edición: mostramos campos editables
            SectionInput(label = "Nombre de la empresa", value = name, onValueChange = { name = it })
            Divider(color = Color(0xFFBDBDBD), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

            SectionInput(label = "Fundada en", value = founded, onValueChange = { founded = it })
            Divider(color = Color(0xFFBDBDBD), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

            SectionInput(label = "Presencia global", value = globalPresence, onValueChange = { globalPresence = it })
            Divider(color = Color(0xFFBDBDBD), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

            SectionInput(label = "Productos innovadores", value = innovativeProducts, onValueChange = { innovativeProducts = it })
            Divider(color = Color(0xFFBDBDBD), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

            SectionInput(label = "Inversión en I+D", value = rAndDInvestment, onValueChange = { rAndDInvestment = it })
            Divider(color = Color(0xFFBDBDBD), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

            SectionInput(label = "Soluciones empresariales", value = enterpriseSolutions, onValueChange = { enterpriseSolutions = it })
            Divider(color = Color(0xFFBDBDBD), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

            SectionInput(
                label = "Misión",
                value = mission,
                onValueChange = { mission = it },
                singleLine = false,
                maxLines = 4
            )
        } else {
            // ─── Modo solo lectura: mostramos cada línea con separador
            InfoLine(label = "Nombre de la empresa:", value = profile.name)
            Divider(color = Color(0xFFBDBDBD), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

            InfoLine(label = "Fundada en:", value = profile.founded)
            Divider(color = Color(0xFFBDBDBD), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

            InfoLine(label = "Presencia global:", value = profile.globalPresence)
            Divider(color = Color(0xFFBDBDBD), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

            InfoLine(label = "Productos innovadores:", value = profile.innovativeProducts)
            Divider(color = Color(0xFFBDBDBD), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

            InfoLine(label = "Inversión en I+D:", value = profile.rAndDInvestment)
            Divider(color = Color(0xFFBDBDBD), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

            InfoLine(label = "Soluciones empresariales:", value = profile.enterpriseSolutions)
            Divider(color = Color(0xFFBDBDBD), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

            InfoLine(label = "Misión:", value = profile.mission)
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Column(modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            color = Color(0xFF424242)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFF212121)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SectionInput(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    singleLine: Boolean = true,
    maxLines: Int = 1
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = singleLine,
        maxLines = maxLines,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
    )
}
