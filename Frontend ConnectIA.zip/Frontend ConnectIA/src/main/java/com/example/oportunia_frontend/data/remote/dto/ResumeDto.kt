package com.example.oportunia_frontend.data.remote.dto

data class ResumeDto(
    val title: String,
    val fileUrl: String
)
