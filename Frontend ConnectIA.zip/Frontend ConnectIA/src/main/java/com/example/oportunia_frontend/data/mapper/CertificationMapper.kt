package com.example.oportunia_frontend.data.mapper

import com.example.oportunia_frontend.data.remote.dto.CertificationDto
import com.example.oportunia_frontend.domain.model.Certification
import javax.inject.Inject

class CertificationMapper @Inject constructor(){
    fun mapToDomain(dto: CertificationDto): Certification = Certification(
        name = dto.name,
        issuer = dto.issuer,
        date = dto.date
    )

    fun mapToDto(model: Certification): CertificationDto = CertificationDto(
        name = model.name,
        issuer = model.issuer,
        date = model.date
    )
}