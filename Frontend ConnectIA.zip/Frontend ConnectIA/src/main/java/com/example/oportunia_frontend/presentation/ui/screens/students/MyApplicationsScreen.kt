package com.example.oportunia_frontend.presentation.ui.screens.students

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.example.oportunia_frontend.domain.model.Job
import com.example.oportunia_frontend.presentation.viewmodel.JobViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyApplicationsScreen(
    navController: NavController,
    jobViewModel: JobViewModel
) {
    LaunchedEffect(Unit) {
        jobViewModel.getAllJobs()
    }

    val scrollState = rememberScrollState()
    val applicationsList by jobViewModel.jobList.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(text = "My applications", color = Color.White)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack, // Usa ArrowBack en vez de ArrowForward
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { navController.navigate("notifications_screen") }) {
                        Icon(Icons.Default.Notifications,
                            contentDescription = "Notifications",
                            tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF2196F3))
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .background(Color.White)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            // Card para campos de búsqueda
            Card(
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = "",
                        onValueChange = {},
                        label = { Text("Search Job") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search Icon"
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = "",
                        onValueChange = {},
                        label = { Text("Job Type") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.List,
                                contentDescription = "Job Type Icon"
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Encabezado: "Recommendation" y "See all"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "See all",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF2196F3),
                    modifier = Modifier.clickable {
                        // Acción para "See all"
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Lista de items de "My Applications"
            if (applicationsList.isEmpty()) {
                Text("No applications found", color = Color.Gray)
            } else {
                applicationsList.forEach { application ->
                    MyApplicationsItem(
                        job = application,
                        navController = navController
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

// Composable para cada item de "My Applications"
@Composable
fun MyApplicationsItem(
    job: Job,
    navController: NavController
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                // Navegación a detalle (si aplica)
                navController.navigate("job_detail/${job.id}")
            },
        elevation = CardDefaults.cardElevation(4.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(modifier = Modifier.padding(16.dp)) {
            // Logo placeholder
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.LightGray),
                contentAlignment = Alignment.Center
            ) {
                Text("Logo", fontSize = 10.sp)
            }
            Spacer(modifier = Modifier.width(8.dp))
            // Información del puesto
            Column(modifier = Modifier.weight(1f)) {
                Text(job.organization.name, style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                Text(job.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                Spacer(modifier = Modifier.height(4.dp))
                Text(job.organization.location, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                Spacer(modifier = Modifier.height(2.dp))
                Text(job.salary, style = MaterialTheme.typography.bodySmall, color = Color.Black)
            }
            Spacer(modifier = Modifier.width(8.dp))
            // Flecha negra
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "More",
                    tint = Color.White
                )
            }
        }
    }
}
