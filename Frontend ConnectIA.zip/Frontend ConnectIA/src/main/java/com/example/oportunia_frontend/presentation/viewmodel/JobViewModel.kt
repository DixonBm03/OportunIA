package com.example.oportunia_frontend.presentation.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.oportunia_frontend.domain.model.Job
import com.example.oportunia_frontend.domain.repository.JobRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Sealed class representing the various states of a job operation.
 * Used to track the loading, success, error, and empty states for job operations.
 */
sealed class JobState {
    /**
     * Initial state before any operation has started
     */
    data object Initial : JobState()

    /**
     * Indicates an operation is in progress
     */
    data object Loading : JobState()

    /**
     * Contains successfully retrieved job data
     * @property job The retrieved job
     */
    data class Success(val job: Job) : JobState()

    /**
     * Indicates no job data is available
     */
    data object Empty : JobState()

    /**
     * Represents an error condition during a job operation
     * @property message The error message describing what went wrong
     */
    data class Error(val message: String) : JobState()
}

@HiltViewModel
class JobViewModel @Inject constructor(
    private val jobRepository: JobRepository
) : ViewModel() {
    // Task list state
    private val _jobList = MutableStateFlow<List<Job>>(emptyList())

    /**
     * Flow of the list of all tasks. Empty list means no tasks or loading.
     */
    val jobList = _jobList.asStateFlow()

    // Task detail state
    private val _job = MutableStateFlow<JobState>(JobState.Initial)

    /**
     * Flow representing the current state of task detail operations
     * (loading, success, error, etc.)
     */
    val job = _job.asStateFlow()

    // Selected task state
    private val _selectedJob = MutableStateFlow<Job?>(null)

    /**
     * Flow of the currently selected task, if any
     */
    val selectedJob = _selectedJob.asStateFlow()

    /**
     * Fetches all jobs from the repository and updates [jobList].
     * Any network errors are logged but not exposed to the UI.
     */
    fun getAllJobs() {
        viewModelScope.launch {
            _jobList.value = emptyList() // Clear before loading
            jobRepository.getAllJobs()
                .onSuccess { tasks ->
                    _jobList.value = tasks
                }
                .onFailure { exception ->
                    Log.e("JobViewModel", "Error fetching jobs: ${exception.message}")
                }
        }
    }

    /**
     * Fetches a specific job by ID and updates both [job] and [selectedJob] states.
     * Updates UI state to reflect loading, success, or error conditions.
     *
     * @param jobId The unique identifier of the job to retrieve
     */
    fun getJobById(jobId: Long) {
        viewModelScope.launch {
            _job.value = JobState.Loading
            jobRepository.getJobById(jobId)
                .onSuccess { job ->
                    _job.value = JobState.Success(job)
                    _selectedJob.value = job
                }
                .onFailure { exception ->
                    _job.value = JobState.Error(exception.message ?: "Unknown error")
                    Log.e("JobViewModel", "Error fetching job by ID: ${exception.message}")
                }
        }
    }
}