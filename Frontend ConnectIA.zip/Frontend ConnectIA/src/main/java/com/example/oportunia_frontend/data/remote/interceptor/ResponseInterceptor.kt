package com.example.oportunia_frontend.data.remote.interceptor

import okhttp3.Interceptor
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import java.io.IOException
import javax.inject.Inject

/**
 * Interceptor to log and optionally modify HTTP responses.
 */
class ResponseInterceptor @Inject constructor() : Interceptor {

    /**
     * Intercepts the HTTP response to log and optionally modify it.
     *
     * @param chain The interceptor chain.
     * @return The intercepted and potentially modified response.
     * @throws IOException If an I/O error occurs during the interception.
     */
    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val response = chain.proceed(chain.request())
        val responseBodyString = response.body?.string()
        println("Raw Response: $responseBodyString")

        return response.newBuilder()
            .body((responseBodyString ?: "").toResponseBody(response.body?.contentType()))
            .build()
    }
}