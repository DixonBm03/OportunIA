package com.example.oportunia_frontend.data.remote.dto

data class OrganizationRepresentativeDto (
    val name: String,
    val position: String,
    val email: String
)