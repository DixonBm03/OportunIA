package com.example.oportunia_frontend.presentation.ui.screens.students

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.oportunia_frontend.presentation.viewmodel.JobViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JobDetailScreen(
    id: Long,
    navController: NavController,
    jobViewModel: JobViewModel
) {
    LaunchedEffect(id) {
        jobViewModel.getJobById(id)
    }

    val job by jobViewModel.selectedJob.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text("Job Detail", color = Color.White)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { navController.navigate("notifications_screen") }) {
                        Icon(Icons.Default.Notifications,
                            contentDescription = "Notifications",
                            tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0xFF2196F3))
            )
        }
    ) { padding ->
        val detail = job

        if (detail == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            // ✅ SCROLLABLE CONTENT AREA
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                Text(detail.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                SectionTitle("Description")
                Text(detail.description)

                Spacer(modifier = Modifier.height(16.dp))
                Divider()
                Spacer(modifier = Modifier.height(16.dp))

                SectionTitle("Organization")
                Text("Name: ${detail.organization.name}")
                Text("Website: ${detail.organization.website}")
                Text("Location: ${detail.organization.location}")

                Spacer(modifier = Modifier.height(16.dp))

                SectionTitle("Representative")
                Text("Name: ${detail.organizationRepresentative.name}")
                Text("Position: ${detail.organizationRepresentative.position}")
                Text("Email: ${detail.organizationRepresentative.email}")

                Spacer(modifier = Modifier.height(16.dp))

                SectionTitle("Job Info")
                Text("Salary: ${detail.salary}")
                Text("Status: ${detail.status}")
                Text("Modality: ${detail.modality}")

                Spacer(modifier = Modifier.height(16.dp))

                SectionTitle("Tags")
                detail.tags.forEach { tag -> Text("• $tag") }

                Spacer(modifier = Modifier.height(8.dp))

                SectionTitle("Areas")
                detail.areas.forEach { area -> Text("• $area") }

                Spacer(modifier = Modifier.height(8.dp))

                SectionTitle("Levels")
                detail.level.forEach { lvl -> Text("• $lvl") }

                Spacer(modifier = Modifier.height(32.dp))

                Button(
                    onClick = { navController.navigate("my_applications") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2196F3))
                ) {
                    Text("Apply", color = Color.White, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(16.dp)) // para evitar que tape contenido inferior
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        color = Color(0xFF0D47A1),
        modifier = Modifier.padding(bottom = 4.dp)
    )
}
