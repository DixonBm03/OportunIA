// File: presentation/ui/screens/company/CompanyJobsScreen.kt
package com.example.oportunia_frontend.presentation.ui.screens.company

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

/**
 * Modelo de datos de un trabajo para la sección “Empresa”.
 */
data class CompanyJob(
    val id: Long,
    val title: String,
    val company: String,
    val location: String,
    val salary: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompanyJobsScreen(navController: NavController) {
    // 1) Lista mutable de trabajos, con dos ejemplos iniciales “mock”
    val jobList = remember {
        mutableStateListOf(
            CompanyJob(
                id = 1,
                title = "Cybersecurity Specialist",
                company = "Microsoft",
                location = "London, UK (On-site)",
                salary = "$12K/mo"
            ),
            CompanyJob(
                id = 2,
                title = "Software Developer",
                company = "Microsoft",
                location = "San José, Costa Rica (Remote)",
                salary = "$12K/mo"
            )
        )
    }

    // 2) Estado para el campo de búsqueda (aún no filtra, pero queda preparado)
    var query by remember { mutableStateOf("") }

    // 3) Estados para los campos del formulario de “nuevo trabajo”
    var newTitle by remember { mutableStateOf("") }
    var newCompany by remember { mutableStateOf("") }
    var newLocation by remember { mutableStateOf("") }
    var newSalary by remember { mutableStateOf("") }

    // 4) Usamos un único LazyColumn para todo: encabezado (search + form) + lista
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // ─── Ítem 1: Campo de búsqueda ───────────────────────────────────────────
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Buscar trabajo") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            )
        }

        // ─── Ítem 2: Título “Crear nuevo trabajo” ───────────────────────────────
        item {
            Text(
                text = "Crear nuevo trabajo",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        // ─── Ítem 3: Campo “Título del puesto” ─────────────────────────────────
        item {
            OutlinedTextField(
                value = newTitle,
                onValueChange = { newTitle = it },
                label = { Text("Título del puesto") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )
        }

        // ─── Ítem 4: Campo “Nombre de la empresa” ──────────────────────────────
        item {
            OutlinedTextField(
                value = newCompany,
                onValueChange = { newCompany = it },
                label = { Text("Nombre de la empresa") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )
        }

        // ─── Ítem 5: Campo “Ubicación” ─────────────────────────────────────────
        item {
            OutlinedTextField(
                value = newLocation,
                onValueChange = { newLocation = it },
                label = { Text("Ubicación") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )
        }

        // ─── Ítem 6: Campo “Salario” ───────────────────────────────────────────
        item {
            OutlinedTextField(
                value = newSalary,
                onValueChange = { newSalary = it },
                label = { Text("Salario") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            )
        }

        // ─── Ítem 7: Botón “Guardar” ────────────────────────────────────────────
        item {
            Button(
                onClick = {
                    // 1) Validamos que no estén vacíos
                    if (
                        newTitle.isNotBlank() &&
                        newCompany.isNotBlank() &&
                        newLocation.isNotBlank() &&
                        newSalary.isNotBlank()
                    ) {
                        // 2) Calculamos un nuevo ID (maxId + 1)
                        val nextId = (jobList.maxOfOrNull { it.id } ?: 0L) + 1L

                        // 3) Creamos la nueva instancia y la agregamos a la lista mutable
                        val jobToAdd = CompanyJob(
                            id = nextId,
                            title = newTitle.trim(),
                            company = newCompany.trim(),
                            location = newLocation.trim(),
                            salary = newSalary.trim()
                        )
                        jobList.add(jobToAdd)

                        // 4) Limpiamos los campos del formulario
                        newTitle = ""
                        newCompany = ""
                        newLocation = ""
                        newSalary = ""
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Text("Guardar")
            }
        }

        // ─── Ítem 8: Espacio y separador antes de la lista ───────────────────────
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Divider()
            Spacer(modifier = Modifier.height(16.dp))
        }

        // ─── Ítem 9: Título “Listado de trabajos” ───────────────────────────────
        item {
            Text(
                text = "Listado de trabajos",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        // ─── Ítems 10+: Cada trabajo en la lista ───────────────────────────────
        items(jobList) { job ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier
                        .weight(1f)
                        .clickable {
                            // Al hacer click en el texto, navegamos al detalle
                            navController.navigate("company_job_detail/${job.id}")
                        }
                    ) {
                        Text(
                            text = job.company,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Text(
                            text = job.title,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = job.location,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Ícono de eliminar
                        IconButton(onClick = { jobList.remove(job) }) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Eliminar trabajo",
                                tint = Color(0xFFD32F2F)
                            )
                        }
                        // Ícono de ver detalle
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "Ver detalle"
                        )
                    }
                }
            }
        }
    }
}
