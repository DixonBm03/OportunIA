package com.example.oportunia_frontend.domain.model

data class Education(
    val institution: String,
    val degree: String,
    val startDate: String,
    val endDate: String
)
