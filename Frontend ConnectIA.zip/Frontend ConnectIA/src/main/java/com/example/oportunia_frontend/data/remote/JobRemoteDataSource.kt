package com.example.oportunia_frontend.data.remote

import com.example.oportunia_frontend.data.datasource.dto.application.JobDto
import com.example.oportunia_frontend.data.remote.api.JobService
import retrofit2.Response
import javax.inject.Inject

class JobRemoteDataSource @Inject constructor(
    private val jobService: JobService
) {
    suspend fun getAllJobs(): Result<List<JobDto>> = safeApiCall {
        jobService.getAllJobs()
    }

    suspend fun getJobById(id: Long): Result<JobDto> = safeApiCall {
        jobService.getJobById(id)
    }

    /**
     * Helper function to handle API calls safely.
     *
     * @param apiCall The suspending function making the API call
     * @return [Result] containing the data if successful, or an exception if failed
     */
    private suspend fun <T> safeApiCall(apiCall: suspend () -> Response<T>): Result<T> = try {
        val response = apiCall()
        if (response.isSuccessful) {
            response.body()?.let {
                Result.success(it)
            } ?: Result.failure(Exception("Response body was null"))
        } else {
            val errorBody = response.errorBody()?.string()
            Result.failure(Exception("API error ${response.code()}: $errorBody"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }
}