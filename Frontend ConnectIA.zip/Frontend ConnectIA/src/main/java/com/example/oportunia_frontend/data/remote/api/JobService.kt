package com.example.oportunia_frontend.data.remote.api
//Dixon Bustos medina
import com.example.oportunia_frontend.data.datasource.dto.application.JobDto
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface JobService {
    @GET("job")
    suspend fun getAllJobs(): Response<List<JobDto>>

    @GET("job/{id}")
    suspend fun getJobById(@Path("id") id: Long): Response<JobDto>
}