package com.example.oportunia_frontend.data.mapper

import com.example.oportunia_frontend.data.datasource.dto.application.JobDto
import com.example.oportunia_frontend.domain.model.Job
import javax.inject.Inject

/**
 * Mapper class for converting between [JobDto] and [Job] models.
 * Provides methods to map data transfer objects (DTOs) to domain models and vice versa.
 */
class JobMapper @Inject constructor(
    private val organizationMapper: OrganizationMapper,
    private val organizationRMapper: OrganizationRMapper
)  {

    /**
     * Maps a [JobDto] to a [Job] domain model.
     *
     * @param dto The [JobDto] to be mapped.
     * @return The mapped [Job] domain model.
     */
    fun mapToDomain(dto: JobDto): Job = Job(
        id = dto.id,
        name = dto.name,
        salary = dto.salary,
        description = dto.description,
        status = dto.status,
        modality = dto.modality,
        tags = dto.tags,
        areas = dto.areas,
        level = dto.level,
        organization = organizationMapper.mapToDomain(dto.organization),
        organizationRepresentative = organizationRMapper.mapToDomain(dto.organizationRepresentative)
    )

    /**
     * Maps a [Job] domain model to a [JobDto].
     *
     * @param model The [Job] domain model to be mapped.
     * @return The mapped [JobDto].
     */
    fun mapToDto(model: Job): JobDto = JobDto(
        id = model.id,
        name = model.name,
        salary = model.salary,
        description = model.description,
        status = model.status,
        modality = model.modality,
        tags = model.tags,
        areas = model.areas,
        level = model.level,
        organization = organizationMapper.mapToDto(model.organization),
        organizationRepresentative = organizationRMapper.mapToDto(model.organizationRepresentative)
    )

    fun mapToDomainList(jobsDto: List<JobDto>): List<Job> {
        return jobsDto.map { mapToDomain(it) }
    }
}