package com.example.oportunia_frontend.data.mapper

import com.example.oportunia_frontend.data.remote.dto.OrganizationRepresentativeDto
import com.example.oportunia_frontend.domain.model.OrganizationRepresentative
import javax.inject.Inject

/**
 * Mapper class for converting between [OrganizationRepresentativeDto] and [OrganizationRepresentative] models.
 * This class is currently not active as the methods are commented out.
 */
class OrganizationRMapper @Inject constructor() {

    /**
     * Maps an [OrganizationRepresentativeDto] to an [OrganizationRepresentative] domain model.
     *
     * @param dto The [OrganizationRepresentativeDto] to be mapped.
     * @return The mapped [OrganizationRepresentative] domain model.
     */
    fun mapToDomain(dto: OrganizationRepresentativeDto): OrganizationRepresentative = OrganizationRepresentative(
        name = dto.name,
        position = dto.position,
        email = dto.email
    )

    /**
     * Maps an [OrganizationRepresentative] domain model to an [OrganizationRepresentativeDto].
     *
     * @param model The [OrganizationRepresentative] domain model to be mapped.
     * @return The mapped [OrganizationRepresentativeDto].
     */
    fun mapToDto(model: OrganizationRepresentative): OrganizationRepresentativeDto = OrganizationRepresentativeDto(
        name = model.name,
        position = model.position,
        email = model.email
    )
}